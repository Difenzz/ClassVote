'use strict';
/**
 * Élection des délégués de classe — serveur.
 *
 * Sécurité (résumé) :
 *  - Identifiants professeurs : chiffrés AES-256-GCM (+ index aveugle HMAC-SHA256 pour la recherche).
 *  - Mots de passe : hachés avec scrypt (sel unique par compte), jamais stockés en clair.
 *  - Vote secret : le serveur ne stocke que des compteurs par binôme + un simple
 *    "a voté" par élève. Aucun lien, aucune date, aucun journal entre un élève et un choix.
 *  - Sessions : jeton aléatoire en cookie HttpOnly / SameSite=Strict, seule l'empreinte SHA-256 est stockée.
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { promisify } = require('util');
const PDFDocument = require('pdfkit');

const scrypt = promisify(crypto.scrypt);

const PORT = Number(process.env.PORT) || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const PUBLIC_DIR = path.join(__dirname, 'public');
const TRUST_PROXY = process.env.TRUST_PROXY === '1';
const SESSION_TTL = 12 * 60 * 60 * 1000; // 12 h
const ELECTION_TTL = 30 * 24 * 60 * 60 * 1000; // 30 jours
const SEATS = 2; // deux délégués titulaires par classe

/* ------------------------------------------------------------------ */
/* Secrets & clés                                                      */
/* ------------------------------------------------------------------ */
fs.mkdirSync(DATA_DIR, { recursive: true, mode: 0o700 });

function loadMasterSecret() {
  if (process.env.APP_SECRET && process.env.APP_SECRET.length >= 32) {
    return Buffer.from(process.env.APP_SECRET, 'utf8');
  }
  const file = path.join(DATA_DIR, 'secret.key');
  if (fs.existsSync(file)) return Buffer.from(fs.readFileSync(file, 'utf8').trim(), 'hex');
  const secret = crypto.randomBytes(32);
  fs.writeFileSync(file, secret.toString('hex'), { mode: 0o600 });
  return secret;
}
function loadInviteCode() {
  if (process.env.TEACHER_INVITE) return process.env.TEACHER_INVITE;
  const file = path.join(DATA_DIR, 'invite.txt');
  if (fs.existsSync(file)) return fs.readFileSync(file, 'utf8').trim();
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 8; i++) code += alphabet[crypto.randomInt(alphabet.length)];
  fs.writeFileSync(file, code, { mode: 0o600 });
  return code;
}

const MASTER = loadMasterSecret();
const INVITE = loadInviteCode();
const derive = (info) => Buffer.from(crypto.hkdfSync('sha256', MASTER, Buffer.alloc(0), info, 32));
const KEY_ENC = derive('delegues:enc:v1');
const KEY_IDX = derive('delegues:idx:v1');

function encrypt(plain) {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', KEY_ENC, iv);
  const enc = Buffer.concat([c.update(String(plain), 'utf8'), c.final()]);
  return Buffer.concat([iv, c.getAuthTag(), enc]).toString('base64');
}
function decrypt(b64) {
  const raw = Buffer.from(b64, 'base64');
  const d = crypto.createDecipheriv('aes-256-gcm', KEY_ENC, raw.subarray(0, 12));
  d.setAuthTag(raw.subarray(12, 28));
  return Buffer.concat([d.update(raw.subarray(28)), d.final()]).toString('utf8');
}
const normId = (s) => String(s).normalize('NFKC').trim().toLowerCase();
const blindIndex = (s) => crypto.createHmac('sha256', KEY_IDX).update(normId(s)).digest('hex');

const SCRYPT = { N: 32768, r: 8, p: 1, maxmem: 128 * 1024 * 1024 };
async function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const key = await scrypt(pw, salt, 64, SCRYPT);
  return `scrypt$${SCRYPT.N}$${SCRYPT.r}$${SCRYPT.p}$${salt.toString('base64')}$${key.toString('base64')}`;
}
async function verifyPassword(pw, stored) {
  const [, N, r, p, saltB64, keyB64] = String(stored).split('$');
  const expected = Buffer.from(keyB64, 'base64');
  const key = await scrypt(pw, Buffer.from(saltB64, 'base64'), expected.length, {
    N: Number(N), r: Number(r), p: Number(p), maxmem: 128 * 1024 * 1024,
  });
  return crypto.timingSafeEqual(key, expected);
}
const DUMMY_HASH_PROMISE = hashPassword('dummy-password-for-timing');

const safeEqual = (a, b) => {
  const A = Buffer.from(String(a)); const B = Buffer.from(String(b));
  return A.length === B.length && crypto.timingSafeEqual(A, B);
};

/* ------------------------------------------------------------------ */
/* Stockage (fichier JSON, écriture atomique)                          */
/* ------------------------------------------------------------------ */
const DB_FILE = path.join(DATA_DIR, 'db.json');
let db = { teachers: {}, elections: {}, sessions: {} };
try { db = Object.assign(db, JSON.parse(fs.readFileSync(DB_FILE, 'utf8'))); } catch { /* première exécution */ }

let saveTimer = null;
function flush() {
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db), { mode: 0o600 });
  fs.renameSync(tmp, DB_FILE);
}
function save() {
  if (saveTimer) return;
  saveTimer = setTimeout(() => { saveTimer = null; flush(); }, 150);
}
function purge() {
  const now = Date.now();
  for (const [k, s] of Object.entries(db.sessions)) if (now - s.created > SESSION_TTL) delete db.sessions[k];
  for (const [id, e] of Object.entries(db.elections)) if (now - e.createdAt > ELECTION_TTL) delete db.elections[id];
  save();
}
purge();
setInterval(purge, 60 * 60 * 1000).unref();

const rid = (n = 9) => crypto.randomBytes(n).toString('base64url');

/* ------------------------------------------------------------------ */
/* Utilitaires HTTP                                                    */
/* ------------------------------------------------------------------ */
class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}
const bad = (msg, status = 400) => new HttpError(status, msg);

function clientIp(req) {
  if (TRUST_PROXY) {
    const xf = req.headers['x-forwarded-for'];
    if (xf) return String(xf).split(',')[0].trim();
  }
  return req.socket.remoteAddress || 'unknown';
}

const buckets = new Map();
function allow(key, max, windowMs) {
  const now = Date.now();
  let b = buckets.get(key);
  if (!b || b.reset < now) { b = { n: 0, reset: now + windowMs }; buckets.set(key, b); }
  b.n += 1;
  return b.n <= max;
}
setInterval(() => { const now = Date.now(); for (const [k, b] of buckets) if (b.reset < now) buckets.delete(k); }, 60 * 1000).unref();

function securityHeaders(res) {
  res.setHeader('Content-Security-Policy',
    "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; font-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'");
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
}

function sendJson(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
}

function readJson(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > 32 * 1024) { reject(bad('Requête trop volumineuse', 413)); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      if (!size) return resolve({});
      try {
        const v = JSON.parse(Buffer.concat(chunks).toString('utf8'));
        resolve(v && typeof v === 'object' ? v : {});
      } catch { reject(bad('JSON invalide')); }
    });
    req.on('error', reject);
  });
}

function parseCookies(req) {
  const out = {};
  String(req.headers.cookie || '').split(';').forEach((p) => {
    const i = p.indexOf('=');
    if (i > 0) out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim());
  });
  return out;
}
const isSecure = (req) => (TRUST_PROXY ? req.headers['x-forwarded-proto'] === 'https' : !!req.socket.encrypted);
const tokenKey = (tok) => crypto.createHash('sha256').update(tok).digest('hex');

function startSession(req, res, data) {
  const tok = crypto.randomBytes(32).toString('base64url');
  db.sessions[tokenKey(tok)] = { ...data, created: Date.now() };
  const flags = ['HttpOnly', 'SameSite=Strict', 'Path=/', `Max-Age=${SESSION_TTL / 1000}`];
  if (isSecure(req)) flags.push('Secure');
  res.setHeader('Set-Cookie', `sid=${tok}; ${flags.join('; ')}`);
  save();
}
function endSession(req, res) {
  const tok = parseCookies(req).sid;
  if (tok) { delete db.sessions[tokenKey(tok)]; save(); }
  res.setHeader('Set-Cookie', 'sid=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0');
}
function getSession(req) {
  const tok = parseCookies(req).sid;
  if (!tok) return null;
  const s = db.sessions[tokenKey(tok)];
  if (!s || Date.now() - s.created > SESSION_TTL) return null;
  return s;
}

/* ------------------------------------------------------------------ */
/* Temps réel (Server-Sent Events)                                     */
/* ------------------------------------------------------------------ */
const clients = new Set();
const pending = new Map();
function notify(e, scope = 'all') {
  const key = e.id + scope;
  if (pending.has(key)) return;
  pending.set(key, setTimeout(() => {
    pending.delete(key);
    for (const c of clients) {
      const hit = c.tid === e.tid || (scope === 'all' && c.eid === e.id);
      if (hit) c.res.write('event: change\ndata: {}\n\n');
    }
  }, 250));
}

/* ------------------------------------------------------------------ */
/* Validation & formatage                                              */
/* ------------------------------------------------------------------ */
const NAME_RE = /^[\p{L}\p{M}][\p{L}\p{M}' .-]{0,39}$/u;
const PSEUDO_RE = /^[\p{L}\p{N}\p{M}][\p{L}\p{N}\p{M}_.' -]{1,23}$/u;
const ID_RE = /^[\p{L}\p{N}._@+-]{3,64}$/u;

const clean = (v) => String(v ?? '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '').replace(/[ \t]+/g, ' ').trim();
function text(v, label, { min = 1, max = 100 } = {}) {
  const s = clean(v);
  if (s.length < min) throw bad(`${label} : champ obligatoire`);
  if (s.length > max) throw bad(`${label} : ${max} caractères maximum`);
  return s;
}
function personName(v, label) {
  const s = clean(v);
  if (!NAME_RE.test(s)) throw bad(`${label} : lettres, espaces, tirets et apostrophes uniquement`);
  return s;
}
const capitalize = (s) => s.toLocaleLowerCase('fr').replace(/(^|[ '-])(\p{L})/gu, (_, sep, ch) => sep + ch.toLocaleUpperCase('fr'));
function readPerson(o, label) {
  o = o || {};
  const prenom = capitalize(personName(o.prenom, `${label} (prénom)`));
  const nom = personName(o.nom, `${label} (nom)`).toLocaleUpperCase('fr');
  return { prenom, nom };
}
const fullName = (p) => `${p.prenom} ${p.nom}`;
const personKey = (p) => `${p.prenom} ${p.nom}`.normalize('NFD').replace(/\p{M}/gu, '').toLowerCase();

/* ------------------------------------------------------------------ */
/* Logique d'élection                                                  */
/* ------------------------------------------------------------------ */
function newCode() {
  const used = new Set(Object.values(db.elections).map((e) => e.code));
  for (let i = 0; i < 50; i++) {
    const c = String(crypto.randomInt(0, 1000000)).padStart(6, '0');
    if (!used.has(c)) return c;
  }
  throw bad('Impossible de générer un code, réessayer', 500);
}
const seatsLeft = (e) => Math.max(0, e.seats - e.elected.length);
const currentRound = (e) => (e.round ? e.rounds[e.round] : null);
const acceptedList = (e) => Object.values(e.participants).filter((p) => p.status === 'accepted');
const threshold = (r) => Math.floor((r.ballots - r.blanks) / 2) + 1;

/** Choisit les élus parmi `eligible` (déjà triés/filtrés) ; renvoie les élus sûrs et une éventuelle égalité. */
function pickWinners(eligible, slots, tally) {
  const sorted = [...eligible].sort((a, b) => tally[b] - tally[a]);
  if (sorted.length <= slots) return { sure: sorted, tie: null };
  const cutoff = tally[sorted[slots - 1]];
  const above = sorted.filter((b) => tally[b] > cutoff);
  const tied = sorted.filter((b) => tally[b] === cutoff);
  if (above.length + tied.length <= slots) return { sure: [...above, ...tied], tie: null };
  return { sure: above, tie: { slots: slots - above.length, candidates: tied } };
}

function startRound(e, n) {
  const candidates = Object.keys(e.binomes).filter((b) => !e.elected.includes(b));
  const tally = {};
  candidates.forEach((b) => { tally[b] = 0; });
  e.rounds[n] = { candidates, ballots: 0, blanks: 0, tally, closed: false };
  e.round = n;
  e.status = 'voting';
}

function closeRound(e) {
  const r = currentRound(e);
  r.closed = true;
  const slots = seatsLeft(e);
  const exprimes = r.ballots - r.blanks;
  let eligible;
  if (e.round === 1) eligible = exprimes > 0 ? r.candidates.filter((b) => r.tally[b] >= threshold(r)) : [];
  else eligible = r.candidates.filter((b) => r.tally[b] > 0);
  const { sure, tie } = pickWinners(eligible, slots, r.tally);
  r.elected = [...sure];
  sure.forEach((b) => e.elected.push(b));
  e.tie = tie;
  e.status = 'results';
  autoFinish(e);
}
function autoFinish(e) {
  if (e.tie) return;
  if (e.status === 'results' && (seatsLeft(e) === 0 || e.round === 2)) e.status = 'finished';
}

/* ------------------------------------------------------------------ */
/* Vues (ce que chaque rôle a le droit de voir)                        */
/* ------------------------------------------------------------------ */
const bView = (e, id) => {
  const b = e.binomes[id];
  return { id, titulaire: fullName(b.titulaire), suppleant: fullName(b.suppleant) };
};
const sortedBinomes = (e) => Object.keys(e.binomes)
  .sort((a, b) => e.binomes[a].titulaire.nom.localeCompare(e.binomes[b].titulaire.nom, 'fr'));

function roundsView(e) {
  return [1, 2].filter((n) => e.rounds[n] && e.rounds[n].closed).map((n) => {
    const r = e.rounds[n];
    return {
      round: n, ballots: r.ballots, blanks: r.blanks, exprimes: r.ballots - r.blanks,
      threshold: n === 1 ? threshold(r) : null,
      elected: r.elected || [],
      tally: r.candidates.map((id) => ({ id, votes: r.tally[id] })).sort((a, b) => b.votes - a.votes),
    };
  });
}

function teacherView(e) {
  const r = currentRound(e);
  const list = Object.values(e.participants);
  return {
    id: e.id, className: e.className, code: e.code, status: e.status, round: e.round,
    seats: e.seats, seatsLeft: seatsLeft(e), createdAt: e.createdAt,
    participants: list.map((p) => ({
      id: p.id, pseudo: p.pseudo, status: p.status, role: p.role,
      voted: !!(r && p.voted[e.round]), joinedAt: p.joinedAt,
    })),
    binomes: sortedBinomes(e).map((id) => ({
      ...bView(e, id),
      registrant: e.participants[e.binomes[id].pid]?.pseudo || '?',
      elected: e.elected.includes(id),
      formAt: e.forms[id]?.submittedAt || null,
    })),
    turnout: r && e.status === 'voting'
      ? { voted: r.ballots, total: acceptedList(e).length } : null,
    rounds: roundsView(e),
    elected: e.elected,
    tie: e.tie ? { slots: e.tie.slots, candidates: e.tie.candidates } : null,
  };
}

function studentView(e, p) {
  const base = { pseudo: p.pseudo, status: p.status, className: e.className };
  if (p.status !== 'accepted') return base;
  const r = currentRound(e);
  const mine = p.binomeId && e.binomes[p.binomeId] ? p.binomeId : null;
  const isElected = !!mine && e.elected.includes(mine);
  const inVote = e.status === 'voting' && r;
  const hasVoted = !!(r && p.voted[e.round]);
  const view = {
    ...base,
    role: p.role,
    phase: { status: e.status, round: e.round, seats: e.seats, seatsLeft: seatsLeft(e), tie: !!e.tie },
    binomes: sortedBinomes(e).map((id) => ({ ...bView(e, id), mine: id === mine })),
    ballotCandidates: inVote ? r.candidates : [],
    maxChoices: inVote ? seatsLeft(e) : 0,
    hasVoted: inVote ? hasVoted : false,
    rounds: roundsView(e),
    elected: e.elected,
    myBinome: mine ? { id: mine, elected: isElected } : null,
  };
  if (isElected) {
    const b = e.binomes[mine];
    const f = e.forms[mine];
    view.form = {
      classe: e.className, titulaire: fullName(b.titulaire), suppleant: fullName(b.suppleant),
      presentation: f?.presentation || '', motivations: f?.motivations || '',
      programme: f?.programme || '', slogan: f?.slogan || '', submittedAt: f?.submittedAt || null,
    };
  }
  return view;
}

/* ------------------------------------------------------------------ */
/* PDF                                                                 */
/* ------------------------------------------------------------------ */
// Helvetica (WinAnsi) : on remplace ce qui n'est pas affichable pour éviter les caractères parasites.
const pdfText = (s) => String(s ?? '').replace(/[^\n\x20-\x7E\u00A0-\u00FF\u2018\u2019\u201C\u201D\u2013\u2014\u2026\u20AC\u0152\u0153]/g, '?');
const slug = (s) => String(s).normalize('NFD').replace(/\p{M}/gu, '').replace(/[^a-zA-Z0-9]+/g, '-').replace(/^-|-$/g, '').toLowerCase() || 'classe';
const frDate = (d) => new Date(d).toLocaleDateString('fr-FR');
const frDateTime = (d) => new Date(d).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' });

function buildPdf(draw) {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ size: 'A4', margin: 56, bufferPages: true });
    const chunks = [];
    doc.on('data', (c) => chunks.push(c));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);
    try { draw(doc); doc.end(); } catch (err) { reject(err); }
  });
}

function acteToPdf(e, binomeId) {
  const b = e.binomes[binomeId];
  const f = e.forms[binomeId] || {};
  return buildPdf((doc) => {
    const left = doc.page.margins.left;
    const width = doc.page.width - left - doc.page.margins.right;
    doc.info.Title = 'Acte de candidature';
    doc.font('Helvetica-Bold').fontSize(20).text('ACTE DE CANDIDATURE', { align: 'center' });
    doc.moveDown(1.2);

    const field = (label, value) => {
      doc.font('Helvetica-Bold').fontSize(11).text(pdfText(label) + ' ', { continued: true });
      doc.font('Helvetica').text(pdfText(value));
      doc.moveDown(0.5);
    };
    field('CLASSE :', e.className);
    field('NOM, PRÉNOM DU TITULAIRE :', fullName(b.titulaire));
    field('NOM, PRÉNOM DU SUPPLÉANT :', fullName(b.suppleant));
    doc.moveDown(0.6);

    const section = (label, value) => {
      doc.font('Helvetica-Bold').fontSize(10.5).text('•  ' + pdfText(label), { width });
      doc.moveDown(0.3);
      const y0 = doc.y;
      doc.font('Helvetica').fontSize(11).text(pdfText(value || ''), left + 14, y0 + 6, { width: width - 28, lineGap: 2 });
      const y1 = Math.max(doc.y + 8, y0 + 34);
      doc.roundedRect(left, y0, width, y1 - y0, 4).lineWidth(0.6).strokeColor('#8892AA').stroke();
      doc.x = left; doc.y = y1 + 14;
    };
    section('PRÉSENTEZ-VOUS BRIÈVEMENT (NOM, ÂGE, QUALITÉS) :', f.presentation);
    section("VOS MOTIVATIONS (POURQUOI VOUS AVEZ CHOISI D'ÊTRE CANDIDATS, COMMENT LE TITULAIRE A CHOISI SON SUPPLÉANT) :", f.motivations);
    section('VOTRE PROGRAMME (VOTRE RÔLE AUPRÈS DE LA CLASSE, DES PROFESSEURS, DE L\u2019ADMINISTRATION, VOS PROJETS) :', f.programme);
    section('VOTRE SLOGAN ? :', f.slogan);

    doc.font('Helvetica-Oblique').fontSize(8.5).fillColor('#5A6480')
      .text(pdfText(`Rempli sur le site d'élection le ${f.submittedAt ? frDateTime(f.submittedAt) : '—'}`), left, doc.y, { width });
  });
}

function drawTable(doc, x, y, widths, rows, { header = true, minH = 24, size = 10 } = {}) {
  let cy = y;
  const total = widths.reduce((a, b) => a + b, 0);
  rows.forEach((row, ri) => {
    const isHead = header && ri === 0;
    doc.font(isHead ? 'Helvetica-Bold' : 'Helvetica').fontSize(size);
    const hs = row.map((c, i) => doc.heightOfString(pdfText(c), { width: widths[i] - 12 }) + 14);
    const h = Math.max(minH, ...hs);
    if (cy + h > doc.page.height - doc.page.margins.bottom) { doc.addPage(); cy = doc.page.margins.top; }
    let cx = x;
    row.forEach((c, i) => {
      if (isHead) doc.rect(cx, cy, widths[i], h).fillAndStroke('#E9EDF6', '#1B2547');
      else doc.rect(cx, cy, widths[i], h).lineWidth(0.7).stroke('#1B2547');
      doc.fillColor('#000').font(isHead ? 'Helvetica-Bold' : 'Helvetica').fontSize(size)
        .text(pdfText(c), cx + 6, cy + 7, { width: widths[i] - 12 });
      cx += widths[i];
    });
    cy += h;
  });
  doc.x = x; doc.y = cy;
  return { y: cy, width: total };
}

function pvToPdf(e, opts) {
  return buildPdf((doc) => {
    const left = doc.page.margins.left;
    const width = doc.page.width - left - doc.page.margins.right;
    const date = opts.date ? new Date(opts.date) : new Date();
    const y0 = date.getMonth() >= 7 ? date.getFullYear() : date.getFullYear() - 1;
    doc.info.Title = 'Procès-verbal d\u2019élection des délégués';

    doc.font('Helvetica-Bold').fontSize(16).text('PROCÈS-VERBAL D\u2019ÉLECTION DES DÉLÉGUÉS DE CLASSE', { align: 'center' });
    doc.moveDown(0.4);
    doc.font('Helvetica').fontSize(11).text(`Année scolaire ${y0}-${y0 + 1}`, { align: 'center' });
    doc.moveDown(1);
    doc.font('Helvetica-Bold').fontSize(11).text(
      pdfText(`Je soussigné(e) ${opts.teacher || '_______________'} déclare avoir fait procéder le ${frDate(date)} à l\u2019élection des deux délégués de la classe de ${e.className}`),
      { width },
    );
    doc.moveDown(1);

    const r1 = e.rounds[1]; const r2 = e.rounds[2];
    const rows = [['TITULAIRE + SON SUPPLÉANT', 'Suffrages obtenus au 1er tour', 'Suffrages obtenus au 2ème tour']];
    sortedBinomes(e).forEach((id) => {
      const b = e.binomes[id];
      rows.push([
        `${fullName(b.titulaire)}  +  ${fullName(b.suppleant)}`,
        r1 && r1.tally[id] !== undefined ? String(r1.tally[id]) : '—',
        r2 && r2.tally[id] !== undefined ? String(r2.tally[id]) : '—',
      ]);
    });
    let t = drawTable(doc, left, doc.y, [width - 250, 125, 125], rows);
    doc.y = t.y + 18;

    const col = (r, absents) => {
      if (!r || !r.closed) return ['—', '—', '—', '—', '—', '—', '—'];
      const votants = r.ballots; const exprimes = r.ballots - r.blanks;
      const abst = Math.max(0, opts.effectif - absents - votants);
      return [
        String(opts.effectif), String(absents), String(abst), String(votants), String(r.blanks), String(exprimes),
        r === r1 ? String(Math.floor(exprimes / 2) + 1) : 'sans objet (majorité relative)',
      ];
    };
    const labels = ['Nombre d\u2019élèves de la classe', 'Nombre d\u2019élèves absents', 'Abstentions', 'Votants',
      'Bulletins blancs ou nuls', 'Suffrages exprimés', 'Majorité absolue (1/2 des voix + 1)'];
    const c1 = col(r1, opts.absents1); const c2 = col(r2, opts.absents2);
    const sumRows = [['', '1er tour', '2ème tour'], ...labels.map((l, i) => [l, c1[i], c2[i]])];
    t = drawTable(doc, left, doc.y, [width - 250, 125, 125], sumRows);
    doc.y = t.y + 18;

    doc.font('Helvetica-Bold').fontSize(11).fillColor('#000').text('Élèves élus délégués :', left, doc.y);
    doc.moveDown(0.5);
    const el = [['TITULAIRE + SUPPLÉANT', 'Régime : D.P, EXT', 'Signatures']];
    for (let i = 0; i < e.seats; i++) {
      const id = e.elected[i];
      el.push([id ? `${fullName(e.binomes[id].titulaire)}  +  ${fullName(e.binomes[id].suppleant)}` : '/', '/', '/']);
    }
    t = drawTable(doc, left, doc.y, [width - 260, 110, 150], el, { minH: 34 });
    doc.y = t.y + 26;

    let sy = doc.y;
    if (sy + 120 > doc.page.height - doc.page.margins.bottom) { doc.addPage(); sy = doc.page.margins.top; }
    doc.font('Helvetica').fontSize(11).fillColor('#000');
    doc.text('Signature du président de séance :', left, sy);
    doc.text(pdfText(`Les assesseurs :   ${[opts.assessor1, opts.assessor2].filter(Boolean).join('   &   ')}`), left, sy + 45);
    doc.text('Binôme de titulaires :', left, sy + 90);
  });
}

/* ------------------------------------------------------------------ */
/* Routes                                                              */
/* ------------------------------------------------------------------ */
const routes = [];
const route = (method, pattern, handler, auth) => {
  const keys = [];
  const re = new RegExp('^' + pattern.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
  routes.push({ method, re, keys, handler, auth });
};

function teacherElection(ctx) {
  const e = db.elections[ctx.params.id];
  if (!e || e.tid !== ctx.session.tid) throw bad('Élection introuvable', 404);
  return e;
}
function studentCtx(ctx) {
  const e = db.elections[ctx.session.eid];
  const p = e && e.participants[ctx.session.pid];
  if (!e || !p) throw bad('Session expirée', 401);
  return { e, p };
}

/* ---- authentification professeurs ---- */
route('POST', '/api/teacher/register', async (ctx) => {
  if (!allow('reg:' + ctx.ip, 5, 60 * 60 * 1000)) throw bad('Trop de tentatives, réessayer plus tard', 429);
  const identifiant = clean(ctx.body.identifiant);
  const password = String(ctx.body.password || '');
  if (!ID_RE.test(identifiant)) throw bad('Identifiant : 3 à 64 caractères (lettres, chiffres, . _ @ + -)');
  if (password.length < 10 || password.length > 128) throw bad('Mot de passe : 10 caractères minimum');
  if (!safeEqual(String(ctx.body.invite || '').trim().toUpperCase(), INVITE.toUpperCase())) throw bad('Code d\u2019invitation incorrect', 403);
  const idx = blindIndex(identifiant);
  if (Object.values(db.teachers).some((t) => t.idx === idx)) throw bad('Cet identifiant est déjà utilisé', 409);
  const id = rid();
  db.teachers[id] = { id, idx, idEnc: encrypt(identifiant), pw: await hashPassword(password), createdAt: Date.now() };
  startSession(ctx.req, ctx.res, { type: 'teacher', tid: id });
  save();
  return { ok: true };
});

route('POST', '/api/teacher/login', async (ctx) => {
  if (!allow('login:' + ctx.ip, 10, 5 * 60 * 1000)) throw bad('Trop de tentatives, réessayer dans quelques minutes', 429);
  const identifiant = clean(ctx.body.identifiant);
  const password = String(ctx.body.password || '');
  const idx = blindIndex(identifiant);
  const teacher = Object.values(db.teachers).find((t) => t.idx === idx);
  const ok = await verifyPassword(password, teacher ? teacher.pw : await DUMMY_HASH_PROMISE);
  if (!teacher || !ok) throw bad('Identifiant ou mot de passe incorrect', 401);
  startSession(ctx.req, ctx.res, { type: 'teacher', tid: teacher.id });
  return { ok: true };
});

route('POST', '/api/logout', async (ctx) => { endSession(ctx.req, ctx.res); return { ok: true }; });

route('GET', '/api/me', async (ctx) => {
  const s = ctx.session;
  if (!s) return { role: null };
  if (s.type === 'teacher') {
    const t = db.teachers[s.tid];
    if (!t) return { role: null };
    return { role: 'teacher', identifiant: decrypt(t.idEnc) };
  }
  const e = db.elections[s.eid];
  if (!e || !e.participants[s.pid]) return { role: null };
  return { role: 'student', pseudo: e.participants[s.pid].pseudo };
});

/* ---- élèves : connexion par code ---- */
route('POST', '/api/join', async (ctx) => {
  if (!allow('join:' + ctx.ip, 20, 60 * 1000)) throw bad('Trop de tentatives, patienter une minute', 429);
  const code = clean(ctx.body.code).replace(/\s/g, '');
  if (!/^\d{6}$/.test(code)) throw bad('Le code contient 6 chiffres');
  const pseudo = clean(ctx.body.pseudo);
  if (!PSEUDO_RE.test(pseudo)) throw bad('Pseudo : 2 à 24 caractères (lettres, chiffres, espaces, . _ \' -)');
  const e = Object.values(db.elections).find((x) => x.code === code);
  if (!e || e.status === 'finished') {
    if (!allow('joinfail:' + ctx.ip, 8, 5 * 60 * 1000)) throw bad('Trop de codes incorrects, réessayer dans quelques minutes', 429);
    throw bad('Code introuvable ou élection terminée', 404);
  }
  const key = pseudo.toLocaleLowerCase('fr');
  const same = Object.values(e.participants).find((p) => p.pseudo.toLocaleLowerCase('fr') === key);
  if (same && same.status !== 'refused') throw bad('Ce pseudo est déjà pris dans cette classe', 409);
  if (same) delete e.participants[same.id];
  const id = rid(6);
  e.participants[id] = { id, pseudo, status: 'pending', role: null, binomeId: null, voted: {}, joinedAt: Date.now() };
  startSession(ctx.req, ctx.res, { type: 'student', eid: e.id, pid: id });
  save(); notify(e, 'teacher');
  return { ok: true };
});

/* ---- flux temps réel ---- */
route('GET', '/api/stream', async (ctx) => {
  const s = ctx.session;
  const client = { res: ctx.res, tid: s.type === 'teacher' ? s.tid : null, eid: s.type === 'student' ? s.eid : null };
  ctx.res.writeHead(200, {
    'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive', 'X-Accel-Buffering': 'no',
  });
  ctx.res.write('retry: 3000\n\n');
  clients.add(client);
  const beat = setInterval(() => ctx.res.write(': ping\n\n'), 25000);
  ctx.req.on('close', () => { clearInterval(beat); clients.delete(client); });
  return undefined; // réponse gardée ouverte
}, 'any');

/* ---- professeur : élections ---- */
route('GET', '/api/teacher/elections', async (ctx) => ({
  elections: Object.values(db.elections).filter((e) => e.tid === ctx.session.tid)
    .sort((a, b) => b.createdAt - a.createdAt)
    .map((e) => ({
      id: e.id, className: e.className, code: e.code, status: e.status, round: e.round, createdAt: e.createdAt,
      accepted: acceptedList(e).length, binomes: Object.keys(e.binomes).length,
    })),
}), 'teacher');

route('POST', '/api/teacher/elections', async (ctx) => {
  const className = text(ctx.body.className, 'Classe', { max: 30 });
  const n = Object.values(db.elections).filter((e) => e.tid === ctx.session.tid && e.status !== 'finished').length;
  if (n >= 20) throw bad('Trop d\u2019élections en cours, en supprimer une');
  const id = rid();
  db.elections[id] = {
    id, tid: ctx.session.tid, className, code: newCode(), createdAt: Date.now(),
    status: 'lobby', round: 0, seats: SEATS, participants: {}, binomes: {}, rounds: {}, elected: [], tie: null, forms: {},
  };
  save();
  return { id };
}, 'teacher');

route('GET', '/api/teacher/elections/:id', async (ctx) => teacherView(teacherElection(ctx)), 'teacher');

route('DELETE', '/api/teacher/elections/:id', async (ctx) => {
  const e = teacherElection(ctx);
  delete db.elections[e.id];
  for (const [k, s] of Object.entries(db.sessions)) if (s.eid === e.id) delete db.sessions[k];
  save(); notify(e);
  return { ok: true };
}, 'teacher');

route('POST', '/api/teacher/elections/:id/participants/:pid', async (ctx) => {
  const e = teacherElection(ctx);
  const p = e.participants[ctx.params.pid];
  if (!p) throw bad('Élève introuvable', 404);
  const d = ctx.body.decision;
  if (d === 'accept') p.status = 'accepted';
  else if (d === 'refuse') p.status = 'refused';
  else if (d === 'remove') {
    if (p.binomeId) removeBinome(e, p.binomeId);
    delete e.participants[p.id];
  } else throw bad('Décision invalide');
  save(); notify(e);
  return { ok: true };
}, 'teacher');

function removeBinome(e, id) {
  const b = e.binomes[id];
  if (!b) return;
  const p = e.participants[b.pid];
  if (p) { p.binomeId = null; p.role = null; }
  delete e.binomes[id];
  delete e.forms[id];
}

route('DELETE', '/api/teacher/elections/:id/binomes/:bid', async (ctx) => {
  const e = teacherElection(ctx);
  if (e.status !== 'lobby') throw bad('Les candidatures sont closes');
  if (!e.binomes[ctx.params.bid]) throw bad('Binôme introuvable', 404);
  removeBinome(e, ctx.params.bid);
  save(); notify(e);
  return { ok: true };
}, 'teacher');

route('POST', '/api/teacher/elections/:id/action', async (ctx) => {
  const e = teacherElection(ctx);
  const type = ctx.body.type;
  if (type === 'startVote') {
    if (e.status !== 'lobby') throw bad('Le vote a déjà commencé');
    if (!Object.keys(e.binomes).length) throw bad('Aucun binôme candidat pour le moment');
    startRound(e, 1);
  } else if (type === 'closeRound') {
    if (e.status !== 'voting') throw bad('Aucun tour en cours');
    closeRound(e);
  } else if (type === 'resolveTie') {
    if (!e.tie) throw bad('Aucune égalité à départager');
    const choices = [...new Set(Array.isArray(ctx.body.choices) ? ctx.body.choices : [])];
    if (choices.length !== e.tie.slots || !choices.every((c) => e.tie.candidates.includes(c))) {
      throw bad(`Sélectionner exactement ${e.tie.slots} binôme(s)`);
    }
    choices.forEach((c) => e.elected.push(c));
    currentRound(e).elected.push(...choices);
    e.tie = null;
    autoFinish(e);
  } else if (type === 'startRound2') {
    if (e.status !== 'results' || e.tie || e.round !== 1) throw bad('Second tour impossible pour le moment');
    if (seatsLeft(e) === 0) throw bad('Tous les sièges sont pourvus');
    if (Object.keys(e.binomes).every((b) => e.elected.includes(b))) throw bad('Aucun binôme restant');
    startRound(e, 2);
  } else if (type === 'finish') {
    if (e.status !== 'results' || e.tie) throw bad('Impossible de terminer maintenant');
    e.status = 'finished';
  } else throw bad('Action inconnue');
  save(); notify(e);
  return teacherView(e);
}, 'teacher');

route('GET', '/api/teacher/elections/:id/forms/:bid', async (ctx) => {
  const e = teacherElection(ctx);
  if (!e.forms[ctx.params.bid]) throw bad('Formulaire non reçu', 404);
  const pdf = await acteToPdf(e, ctx.params.bid);
  const b = e.binomes[ctx.params.bid];
  return { pdf, filename: `acte-candidature-${slug(e.className)}-${slug(b.titulaire.nom)}.pdf` };
}, 'teacher');

route('GET', '/api/teacher/elections/:id/pv', async (ctx) => {
  const e = teacherElection(ctx);
  if (!e.rounds[1] || !e.rounds[1].closed) throw bad('Aucun tour terminé : le procès-verbal n\u2019est pas encore disponible');
  const q = ctx.url.searchParams;
  const num = (k) => Math.max(0, Math.min(2000, parseInt(q.get(k), 10) || 0));
  const opts = {
    teacher: clean(q.get('teacher')).slice(0, 60),
    assessor1: clean(q.get('assessor1')).slice(0, 60),
    assessor2: clean(q.get('assessor2')).slice(0, 60),
    date: /^\d{4}-\d{2}-\d{2}$/.test(q.get('date') || '') ? q.get('date') : null,
    effectif: num('effectif') || acceptedList(e).length,
    absents1: num('absents1'),
    absents2: num('absents2'),
  };
  const pdf = await pvToPdf(e, opts);
  return { pdf, filename: `proces-verbal-${slug(e.className)}.pdf` };
}, 'teacher');

/* ---- élève ---- */
route('GET', '/api/student/state', async (ctx) => {
  const { e, p } = studentCtx(ctx);
  return studentView(e, p);
}, 'student');

route('POST', '/api/student/role', async (ctx) => {
  const { e, p } = studentCtx(ctx);
  if (p.status !== 'accepted') throw bad('Validation du professeur en attente', 403);
  if (p.role) throw bad('Rôle déjà choisi');
  if (ctx.body.role === 'voter') {
    p.role = 'voter';
  } else if (ctx.body.role === 'candidate') {
    if (e.status !== 'lobby') throw bad('Les candidatures sont closes');
    const titulaire = readPerson(ctx.body.titulaire, 'Titulaire');
    const suppleant = readPerson(ctx.body.suppleant, 'Suppléant');
    if (personKey(titulaire) === personKey(suppleant)) throw bad('Le titulaire et le suppléant doivent être deux élèves différents');
    const taken = new Set(Object.values(e.binomes).flatMap((b) => [personKey(b.titulaire), personKey(b.suppleant)]));
    if (taken.has(personKey(titulaire)) || taken.has(personKey(suppleant))) throw bad('Un de ces élèves fait déjà partie d\u2019un binôme');
    const id = rid(6);
    e.binomes[id] = { id, pid: p.id, titulaire, suppleant, createdAt: Date.now() };
    p.role = 'candidate'; p.binomeId = id;
  } else throw bad('Rôle invalide');
  save(); notify(e);
  return { ok: true };
}, 'student');

route('POST', '/api/student/withdraw', async (ctx) => {
  const { e, p } = studentCtx(ctx);
  if (e.status !== 'lobby') throw bad('Les candidatures sont closes');
  if (!p.binomeId) throw bad('Aucune candidature à retirer');
  removeBinome(e, p.binomeId);
  save(); notify(e);
  return { ok: true };
}, 'student');

route('POST', '/api/student/vote', async (ctx) => {
  const { e, p } = studentCtx(ctx);
  const r = currentRound(e);
  if (p.status !== 'accepted') throw bad('Validation du professeur en attente', 403);
  if (e.status !== 'voting' || !r) throw bad('Aucun vote en cours');
  if (p.voted[e.round]) throw bad('Vote déjà enregistré', 409);
  if (ctx.body.blank === true) {
    r.ballots += 1; r.blanks += 1;
  } else {
    const choices = [...new Set(Array.isArray(ctx.body.choices) ? ctx.body.choices.map(String) : [])];
    if (!choices.length) throw bad('Choisir au moins un binôme ou voter blanc');
    if (choices.length > seatsLeft(e)) throw bad(`Maximum ${seatsLeft(e)} choix`);
    if (!choices.every((c) => r.candidates.includes(c))) throw bad('Binôme invalide');
    r.ballots += 1;
    choices.forEach((c) => { r.tally[c] += 1; });
  }
  // Bulletin secret : on note seulement QUI a voté (émargement), jamais POUR QUI.
  p.voted[e.round] = true;
  save(); notify(e, 'teacher');
  return { ok: true };
}, 'student');

function readForm(body) {
  return {
    presentation: text(body.presentation, 'Présentation', { max: 1200 }),
    motivations: text(body.motivations, 'Motivations', { max: 1200 }),
    programme: text(body.programme, 'Programme', { max: 1200 }),
    slogan: text(body.slogan, 'Slogan', { max: 140 }),
  };
}
route('POST', '/api/student/form', async (ctx) => {
  const { e, p } = studentCtx(ctx);
  const id = p.binomeId;
  if (!id || !e.elected.includes(id)) throw bad('Seul le binôme élu peut remplir l\u2019acte de candidature', 403);
  // NB : les champs multi-lignes gardent leurs retours à la ligne
  const keepNl = (v) => String(v ?? '').replace(/\r/g, '');
  const body = {};
  for (const k of ['presentation', 'motivations', 'programme', 'slogan']) body[k] = keepNl(ctx.body[k]);
  const fields = readForm(body);
  e.forms[id] = { ...fields, submittedAt: Date.now() };
  save(); notify(e);
  return { ok: true };
}, 'student');

route('GET', '/api/student/form.pdf', async (ctx) => {
  const { e, p } = studentCtx(ctx);
  if (!p.binomeId || !e.forms[p.binomeId]) throw bad('Formulaire non envoyé', 404);
  return { pdf: await acteToPdf(e, p.binomeId), filename: `acte-candidature-${slug(e.className)}.pdf` };
}, 'student');

/* ------------------------------------------------------------------ */
/* Serveur                                                             */
/* ------------------------------------------------------------------ */
const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.woff2': 'font/woff2', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8',
};

function serveStatic(req, res, pathname) {
  let rel = decodeURIComponent(pathname);
  if (rel === '/') rel = '/index.html';
  const file = path.normalize(path.join(PUBLIC_DIR, rel));
  if (!file.startsWith(PUBLIC_DIR + path.sep)) { res.writeHead(403); return res.end(); }
  fs.readFile(file, (err, buf) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('Page introuvable'); }
    const ext = path.extname(file);
    res.writeHead(200, {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Cache-Control': ext === '.woff2' ? 'public, max-age=31536000, immutable' : 'no-cache',
    });
    res.end(buf);
  });
}

const server = http.createServer(async (req, res) => {
  securityHeaders(res);
  const url = new URL(req.url, 'http://localhost');
  try {
    if (!url.pathname.startsWith('/api/')) {
      if (req.method !== 'GET' && req.method !== 'HEAD') throw bad('Méthode non autorisée', 405);
      return serveStatic(req, res, url.pathname);
    }
    if (req.method !== 'GET') {
      // Protection CSRF : JSON obligatoire + même origine
      const origin = req.headers.origin;
      if (origin && new URL(origin).host !== req.headers.host) throw bad('Origine refusée', 403);
      const ct = String(req.headers['content-type'] || '');
      if (req.method !== 'DELETE' && !ct.startsWith('application/json')) throw bad('Content-Type invalide', 415);
    }
    const r = routes.find((x) => x.method === req.method && x.re.test(url.pathname));
    if (!r) throw bad('Route inconnue', 404);
    const m = url.pathname.match(r.re);
    const params = {}; r.keys.forEach((k, i) => { params[k] = decodeURIComponent(m[i + 1]); });
    const session = getSession(req);
    if (r.auth) {
      if (!session || (r.auth !== 'any' && session.type !== r.auth)) throw bad('Connexion requise', 401);
    }
    const ctx = {
      req, res, url, params, session, ip: clientIp(req),
      body: req.method === 'GET' ? {} : await readJson(req),
    };
    const out = await r.handler(ctx);
    if (out === undefined) return; // SSE
    if (out && out.pdf) {
      res.writeHead(200, {
        'Content-Type': 'application/pdf', 'Cache-Control': 'no-store',
        'Content-Disposition': `inline; filename="${out.filename}"`,
      });
      return res.end(out.pdf);
    }
    sendJson(res, 200, out);
  } catch (err) {
    if (err instanceof HttpError) return sendJson(res, err.status, { error: err.message });
    console.error(err);
    sendJson(res, 500, { error: 'Erreur interne du serveur' });
  }
});

function shutdown() { try { flush(); } catch { /* ignore */ } process.exit(0); }
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

server.listen(PORT, () => {
  console.log(`\n  Élection des délégués — http://localhost:${PORT}`);
  console.log(`  Code d'invitation professeur : ${INVITE}\n`);
});

module.exports = { server };
