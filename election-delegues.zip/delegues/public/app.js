(() => {
  'use strict';

  /* ------------------------------------------------------------ */
  /* Outils                                                        */
  /* ------------------------------------------------------------ */
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => [...el.querySelectorAll(s)];
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const fmtDate = (t) => new Date(t).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' });
  const plural = (n, one, many) => `${n} ${n > 1 ? many : one}`;

  async function api(path, { method = 'GET', body } = {}) {
    const opts = { method, credentials: 'same-origin', headers: {} };
    if (method !== 'GET') { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(body || {}); }
    const r = await fetch('/api' + path, opts);
    let data = null;
    try { data = await r.json(); } catch { /* pas de JSON */ }
    if (!r.ok) {
      const err = new Error((data && data.error) || 'Erreur inattendue');
      err.status = r.status;
      throw err;
    }
    return data;
  }

  let toastTimer;
  function toast(msg, isError = false) {
    const t = $('#toast');
    t.textContent = msg;
    t.classList.toggle('error', isError);
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove('show'), 3200);
  }

  /* ------------------------------------------------------------ */
  /* État                                                          */
  /* ------------------------------------------------------------ */
  const S = {
    me: null, tab: 'student', tmode: 'login',
    list: null, election: null, currentId: null,
    student: null, roleForm: false,
    selection: new Set(), selRound: null,
    dismissed: new Set(),
  };

  const STATUS_LABEL = { lobby: 'Candidatures', voting: 'Vote en cours', results: 'Résultats', finished: 'Terminée' };

  /* ------------------------------------------------------------ */
  /* Montage par régions (évite d'écraser les formulaires en cours) */
  /* ------------------------------------------------------------ */
  let screenKey = null;
  const cache = {};
  function mount(key, skeleton, regions) {
    const main = $('#main');
    if (key !== screenKey) {
      main.innerHTML = skeleton;
      screenKey = key;
      Object.keys(cache).forEach((k) => delete cache[k]);
    }
    let changed = false;
    for (const [name, html] of Object.entries(regions)) {
      if (cache[name] === html) continue;
      const el = main.querySelector(`[data-region="${name}"]`);
      if (!el) continue;
      el.innerHTML = html;
      cache[name] = html;
      $$('[data-w]', el).forEach((i) => { i.style.width = `${Math.max(0, Math.min(100, Number(i.dataset.w) || 0))}%`; });
      changed = true;
    }
    if (changed) syncSelection();
  }
  const spinner = () => mount('loading', '<div class="spinner" role="status" aria-label="Chargement"></div>', {});

  /* ------------------------------------------------------------ */
  /* Composants                                                    */
  /* ------------------------------------------------------------ */
  function ballot(b, { button = false, cls = '', tag = '' } = {}) {
    const inner = `<span class="stub"><span class="box"><span class="stamp"></span></span></span>
      <span class="body">${tag ? `<span class="tag-row">${tag}</span>` : ''}
        <span class="pair"><span class="role">Titulaire</span><span class="who">${esc(b.titulaire)}</span></span>
        <span class="pair"><span class="role">Suppléant</span><span class="who second">${esc(b.suppleant)}</span></span>
      </span>`;
    return button
      ? `<button type="button" class="ballot ${cls}" data-action="toggle" data-id="${esc(b.id)}" aria-pressed="false">${inner}</button>`
      : `<div class="ballot static ${cls}">${inner}</div>`;
  }

  function stepper(status, round, hasR2) {
    const labels = ['Candidatures', '1er tour', '2nd tour', 'Terminé'];
    const cur = status === 'lobby' ? 0 : status === 'finished' ? 4 : round === 1 ? 1 : 2;
    return `<ol class="stepper" aria-label="Étapes de l'élection">${labels.map((l, i) => {
      let c = i < cur ? 'done' : i === cur ? 'current' : '';
      if (i === 2 && status === 'finished' && !hasR2) c = 'skipped';
      return `<li class="${c}"${i === cur ? ' aria-current="step"' : ''}>${l}</li>`;
    }).join('')}</ol>`;
  }

  function resultsPanels(rounds, binomes, elected) {
    if (!rounds.length) return '';
    const by = Object.fromEntries(binomes.map((b) => [b.id, b]));
    return rounds.map((r) => `
      <div class="panel">
        <div class="panel-head"><h3>Résultats du ${r.round === 1 ? '1er' : '2nd'} tour</h3>
          <span class="chip grey">${r.round === 1 ? 'Majorité absolue' : 'Majorité relative'}</span></div>
        <div class="stats">
          <span>Votants : <b>${r.ballots}</b></span><span>Blancs : <b>${r.blanks}</b></span>
          <span>Suffrages exprimés : <b>${r.exprimes}</b></span>
          ${r.threshold ? `<span>Majorité absolue : <b>${r.threshold}</b> voix</span>` : ''}
        </div>
        ${r.tally.map((t) => {
    const b = by[t.id]; if (!b) return '';
    const isEl = (r.elected || []).includes(t.id);
    return `<div class="result ${isEl ? 'elected' : ''}">
            <div class="line"><span class="name">${esc(b.titulaire)} + ${esc(b.suppleant)} ${isEl ? '<span class="chip green">Élu</span>' : ''}</span>
            <span class="votes" aria-label="${t.votes} voix">${t.votes}</span></div>
            <div class="bar" aria-hidden="true"><i data-w="${r.exprimes ? Math.round((t.votes / r.exprimes) * 100) : 0}"></i></div>
          </div>`;
  }).join('')}
      </div>`).join('');
  }

  /* ------------------------------------------------------------ */
  /* Modales                                                       */
  /* ------------------------------------------------------------ */
  function modal(title, body, buttons) {
    return new Promise((resolve) => {
      const d = $('#modal');
      d.innerHTML = `<form method="dialog"><h2 id="modal-title">${esc(title)}</h2><div>${body}</div>
        <div class="actions">${buttons.map((b) => `<button class="btn ${b.cls || ''}" value="${esc(b.value)}"${b.value === 'cancel' ? ' formnovalidate' : ''}>${esc(b.label)}</button>`).join('')}</div></form>`;
      d.addEventListener('close', () => resolve({ value: d.returnValue, form: new FormData($('form', d)) }), { once: true });
      d.returnValue = '';
      d.showModal();
    });
  }
  const confirmBox = async (title, body, label, cls = '') =>
    (await modal(title, body, [{ label: 'Annuler', value: 'cancel', cls: 'secondary' }, { label, value: 'ok', cls }])).value === 'ok';

  function updateApprove() {
    const d = $('#approve');
    const e = S.election;
    const pend = S.me && S.me.role === 'teacher' && S.currentId && e
      ? e.participants.filter((p) => p.status === 'pending' && !S.dismissed.has(p.id)) : [];
    if (!pend.length) { if (d.open) d.close(); d.dataset.sig = ''; return; }
    const p = pend[0];
    const sig = `${p.id}|${pend.length}`;
    if (d.dataset.sig === sig && d.open) return;
    d.dataset.sig = sig; d.dataset.pid = p.id;
    d.innerHTML = `<h2 id="approve-title">Nouvelle connexion</h2>
      <p>Un élève veut rejoindre la classe de <b>${esc(e.className)}</b>. Valider ce pseudo ?</p>
      <div class="pseudo">${esc(p.pseudo)}</div>
      ${pend.length > 1 ? `<p class="muted small">${plural(pend.length - 1, 'autre élève attend', 'autres élèves attendent')}</p>` : ''}
      <div class="actions">
        <button class="btn danger" data-action="refuse" data-pid="${esc(p.id)}">Refuser</button>
        <button class="btn ok" data-action="accept" data-pid="${esc(p.id)}">Accepter</button>
      </div>
      <div class="actions"><button class="btn ghost small" data-action="later">Décider plus tard</button></div>`;
    if (!d.open) d.showModal();
  }
  $('#approve').addEventListener('close', () => {
    const d = $('#approve');
    const p = S.election && S.election.participants.find((x) => x.id === d.dataset.pid);
    if (p && p.status === 'pending') S.dismissed.add(p.id);
    d.dataset.sig = '';
    if (S.election) setTimeout(updateApprove, 0);
  });

  /* ------------------------------------------------------------ */
  /* Barre du haut                                                 */
  /* ------------------------------------------------------------ */
  function renderTopbar() {
    const el = $('#topbar-right');
    const m = S.me;
    if (!m || !m.role) { el.innerHTML = ''; return; }
    const who = m.role === 'teacher' ? m.identifiant : m.pseudo;
    el.innerHTML = `<span class="who-chip">${m.role === 'teacher' ? 'Professeur' : 'Élève'} : <b>${esc(who)}</b></span>
      <button class="btn ghost small" data-action="logout">${m.role === 'teacher' ? 'Se déconnecter' : 'Quitter'}</button>`;
  }

  /* ------------------------------------------------------------ */
  /* Accueil / connexion                                           */
  /* ------------------------------------------------------------ */
  function renderAuth() {
    const prefill = new URLSearchParams(location.search).get('code') || '';
    const student = `
      <h2>Rejoindre la classe</h2>
      <p class="sub">Saisir le code à 6 chiffres donné par le professeur.</p>
      <form data-form="join" novalidate>
        <div class="field"><label for="code">Code de la classe</label>
          <input class="code-input" id="code" name="code" type="text" inputmode="numeric" autocomplete="one-time-code" maxlength="6" placeholder="000000" value="${esc(prefill.replace(/\D/g, '').slice(0, 6))}" required></div>
        <div class="field"><label for="pseudo">Ton pseudo</label>
          <input id="pseudo" name="pseudo" type="text" maxlength="24" autocomplete="nickname" required>
          <span class="hint">Le professeur devra le valider. Utiliser un pseudo qu'il reconnaîtra.</span></div>
        <p class="err" role="alert" data-err></p>
        <button class="btn big wide" type="submit">Rejoindre</button>
      </form>`;
    const teacher = S.tmode === 'login' ? `
      <h2>Espace professeur</h2>
      <p class="sub">Se connecter pour créer une élection et générer le code.</p>
      <form data-form="tlogin" novalidate>
        <div class="field"><label for="tid">Identifiant</label><input id="tid" name="identifiant" type="text" autocomplete="username" required></div>
        <div class="field"><label for="tpw">Mot de passe</label><input id="tpw" name="password" type="password" autocomplete="current-password" required></div>
        <p class="err" role="alert" data-err></p>
        <button class="btn big wide" type="submit">Se connecter</button>
      </form>
      <p class="switch-link">Pas encore de compte ? <button class="linkbtn" data-action="tmode" data-mode="register">Créer un compte</button></p>` : `
      <h2>Créer un compte</h2>
      <p class="sub">Réservé aux professeurs : le code d'invitation est fourni par l'administrateur du site.</p>
      <form data-form="tregister" novalidate>
        <div class="field"><label for="rid">Identifiant</label><input id="rid" name="identifiant" type="text" autocomplete="username" required>
          <span class="hint">Stocké chiffré sur le serveur.</span></div>
        <div class="field"><label for="rpw">Mot de passe</label><input id="rpw" name="password" type="password" autocomplete="new-password" minlength="10" required>
          <span class="hint">10 caractères minimum. Stocké haché, jamais lisible.</span></div>
        <div class="field"><label for="rinv">Code d'invitation</label><input id="rinv" name="invite" type="text" autocomplete="off" required></div>
        <p class="err" role="alert" data-err></p>
        <button class="btn big wide" type="submit">Créer mon compte</button>
      </form>
      <p class="switch-link">Déjà un compte ? <button class="linkbtn" data-action="tmode" data-mode="login">Se connecter</button></p>`;

    const card = `<div class="auth-card">
      <div class="tabs" role="tablist" aria-label="Type de connexion">
        <button class="tab" role="tab" data-action="tab" data-tab="student" aria-selected="${S.tab === 'student'}">Élève</button>
        <button class="tab" role="tab" data-action="tab" data-tab="teacher" aria-selected="${S.tab === 'teacher'}">Professeur</button>
      </div>
      <div role="tabpanel">${S.tab === 'student' ? student : teacher}</div></div>`;

    const skeleton = `<div class="landing">
      <div class="poster">
        <h1>Élisez vos délégués</h1>
        <p class="lead">Un vote de classe simple, rapide et à bulletin secret.</p>
        <ol class="steps">
          <li><span>Le professeur génère un code à 6 chiffres.</span></li>
          <li><span>Les élèves se connectent avec ce code, puis choisissent d'être candidat ou électeur.</span></li>
          <li><span>Chacun vote. Le site ne garde aucun lien entre un élève et son choix.</span></li>
        </ol>
        <div class="specimen" aria-hidden="true">
          <div class="ballot static"><span class="stub"><span class="box"><span class="stamp" style="display:block"></span></span></span>
            <span class="body"><span class="pair"><span class="role">Exemple de bulletin</span><span class="who">Titulaire</span></span>
            <span class="pair"><span class="who second">Suppléant</span></span></span></div>
        </div>
      </div>
      <section data-region="card"></section></div>`;
    mount('auth', skeleton, { card });
  }

  /* ------------------------------------------------------------ */
  /* Professeur : liste                                            */
  /* ------------------------------------------------------------ */
  function renderTeacherList() {
    if (!S.list) return spinner();
    const skeleton = `<div class="teacher"><section data-region="new"></section><section data-region="list" class="stack"></section></div>`;
    const nw = `<div class="panel"><h2>Nouvelle élection</h2>
      <p class="muted" style="margin-bottom:14px">Une élection par classe. Un code à 6 chiffres est généré automatiquement.</p>
      <form data-form="newElection" novalidate class="row" style="align-items:flex-start">
        <div class="field" style="flex:1;min-width:200px;margin:0"><label class="sr" for="cn">Nom de la classe</label>
          <input id="cn" name="className" type="text" maxlength="30" placeholder="Nom de la classe, par ex. 2nde 4" required>
          <p class="err" role="alert" data-err style="margin:6px 0 0"></p></div>
        <button class="btn" type="submit">Créer et générer le code</button></form></div>`;
    const list = `<h2>Mes élections</h2>` + (S.list.length ? S.list.map((e) => `
      <a class="election-row" href="#/e/${esc(e.id)}">
        <div><div class="title">${esc(e.className)}</div>
          <div class="muted small">${plural(e.accepted, 'élève', 'élèves')}, ${plural(e.binomes, 'binôme', 'binômes')}, créée le ${fmtDate(e.createdAt)}</div></div>
        <div style="text-align:right"><div class="code-mini" aria-label="Code ${esc(e.code.split('').join(' '))}">${esc(e.code)}</div>
          <span class="chip ${e.status === 'finished' ? 'green' : e.status === 'voting' ? 'amber' : ''}">${STATUS_LABEL[e.status]}${e.status === 'voting' ? ` (tour ${e.round})` : ''}</span></div>
      </a>`).join('') : `<div class="empty">Aucune élection pour le moment. Créer la première ci-dessus.</div>`);
    mount('t-list', skeleton, { new: nw, list });
  }

  /* ------------------------------------------------------------ */
  /* Professeur : console d'élection                               */
  /* ------------------------------------------------------------ */
  function renderTeacherElection() {
    const e = S.election;
    if (!e) return spinner();
    const accepted = e.participants.filter((p) => p.status === 'accepted');
    const pending = e.participants.filter((p) => p.status === 'pending');
    const hasR2 = e.rounds.some((r) => r.round === 2) || e.round === 2;
    const nameOf = (id) => { const b = e.binomes.find((x) => x.id === id); return b ? `${b.titulaire} + ${b.suppleant}` : '?'; };

    const skeleton = `<div class="teacher"><div class="console">
      <section data-region="head" class="head"></section>
      <div class="col"><section data-region="action"></section><section data-region="results" class="stack"></section><section data-region="forms"></section></div>
      <div class="col"><section data-region="binomes"></section><section data-region="people"></section><section data-region="danger"></section></div>
    </div></div>`;

    const head = `<div><a class="back" href="#/">← Mes élections</a></div>
      <div class="head-top"><div><h1>${esc(e.className)}</h1>
        <p class="muted" style="margin-top:8px">Les élèves se connectent sur <b>${esc(location.host)}</b> avec ce code :</p></div>
        <div class="code-block"><div class="code" role="img" aria-label="Code ${e.code.split('').join(' ')}">${e.code.split('').map((d) => `<span class="digit">${d}</span>`).join('')}</div>
          <div class="row"><button class="btn secondary small" data-action="copy-code" data-code="${esc(e.code)}">Copier le code</button>
          <button class="btn ghost small" data-action="copy-link" data-code="${esc(e.code)}">Copier le lien</button></div></div></div>
      ${stepper(e.status, e.round, hasR2)}`;

    let action = '';
    if (e.status === 'lobby') {
      action = `<div class="panel"><div class="panel-head"><h2>Candidatures ouvertes</h2><span class="chip"><span class="dot pulse"></span>En attente d'élèves</span></div>
        <p>${plural(accepted.length, 'élève validé', 'élèves validés')}, ${plural(e.binomes.length, 'binôme candidat', 'binômes candidats')}${pending.length ? `, <b>${plural(pending.length, 'pseudo à valider', 'pseudos à valider')}</b>` : ''}.</p>
        <p class="muted small" style="margin:6px 0 16px">Ouvrir le vote quand toutes les candidatures sont enregistrées. Ensuite, plus aucune candidature n'est possible.</p>
        <button class="btn big" data-action="start-vote" ${e.binomes.length ? '' : 'disabled'}>Ouvrir le vote (1er tour)</button>
        ${e.binomes.length ? '' : '<p class="hint" style="margin-top:8px">Au moins un binôme doit être candidat.</p>'}</div>`;
    } else if (e.status === 'voting') {
      const t = e.turnout || { voted: 0, total: accepted.length };
      action = `<div class="panel"><div class="panel-head"><h2>${e.round === 1 ? '1er' : '2nd'} tour en cours</h2><span class="chip amber"><span class="dot pulse"></span>Vote ouvert</span></div>
        <p><b>${t.voted}</b> ${t.voted > 1 ? 'bulletins déposés' : 'bulletin déposé'} sur <b>${t.total}</b> ${t.total > 1 ? 'élèves validés' : 'élève validé'}.</p>
        <div class="bar" style="margin:12px 0" aria-hidden="true"><i data-w="${t.total ? Math.round((t.voted / t.total) * 100) : 0}"></i></div>
        <p class="muted small" style="margin-bottom:16px">${e.round === 1 ? `Chaque élève choisit jusqu'à ${e.seatsLeft} binômes. Élection dès la majorité absolue.` : `Chaque élève choisit jusqu'à ${e.seatsLeft} binôme${e.seatsLeft > 1 ? 's' : ''}. Majorité relative : les plus votés sont élus.`}
          Les résultats restent cachés jusqu'à la clôture.</p>
        <button class="btn big" data-action="close-round">Clôturer le ${e.round === 1 ? '1er' : '2nd'} tour</button></div>`;
    } else if (e.status === 'results') {
      if (e.tie) {
        action = `<div class="panel"><div class="panel-head"><h2>Égalité à départager</h2><span class="chip amber">Action requise</span></div>
          <div class="notice amber">Règle du dossier : en cas d'égalité des voix, le candidat titulaire le plus jeune est déclaré élu.</div>
          <form data-form="tie" novalidate><div class="tie-choices" role="group" aria-label="Binômes à égalité">
            ${e.tie.candidates.map((id) => `<label class="check"><input type="${e.tie.slots === 1 ? 'radio' : 'checkbox'}" name="tie" value="${esc(id)}"><span>${esc(nameOf(id))}</span></label>`).join('')}</div>
          <p class="hint" style="margin-bottom:12px">Sélectionner ${e.tie.slots === 1 ? 'le binôme élu' : `${e.tie.slots} binômes`}.</p>
          <p class="err" role="alert" data-err></p>
          <button class="btn" type="submit" data-slots="${e.tie.slots}">Valider le départage</button></form></div>`;
      } else {
        action = `<div class="panel"><div class="panel-head"><h2>${e.round === 1 ? '1er' : '2nd'} tour terminé</h2></div>
          <p><b>${plural(e.elected.length, 'binôme élu', 'binômes élus')}</b> sur ${e.seats}.</p>
          ${e.seatsLeft > 0 ? `<p class="muted small" style="margin:6px 0 16px">${plural(e.seatsLeft, 'siège reste', 'sièges restent')} à pourvoir. Le second tour se joue à la majorité relative entre les binômes non élus.</p>
            <div class="row"><button class="btn big" data-action="start-round2">Lancer le second tour</button>
            <button class="btn secondary" data-action="finish">Terminer sans second tour</button></div>` : ''}</div>`;
      }
    } else {
      action = `<div class="panel"><div class="notice green"><b>Élection terminée.</b> ${plural(e.elected.length, 'binôme élu', 'binômes élus')}${e.elected.length < e.seats ? ` (${plural(e.seats - e.elected.length, 'siège non pourvu', 'sièges non pourvus')})` : ''}.</div></div>`;
    }

    const results = resultsPanels(e.rounds, e.binomes, e.elected);

    const electedRows = e.binomes.filter((b) => b.elected);
    const forms = `<div class="panel"><div class="panel-head"><h2>Actes de candidature</h2>
        <span class="chip ${electedRows.length && electedRows.every((b) => b.formAt) ? 'green' : 'grey'}">${electedRows.filter((b) => b.formAt).length} / ${electedRows.length} reçu${electedRows.length > 1 ? 's' : ''}</span></div>
      ${electedRows.length ? electedRows.map((b) => `<div class="person"><div><div class="nm">${esc(b.titulaire)} + ${esc(b.suppleant)}</div>
          <div class="muted small">${b.formAt ? `Reçu le ${fmtDate(b.formAt)}` : 'En attente du formulaire'}</div></div>
          <div class="meta">${b.formAt ? `<a class="btn small" href="/api/teacher/elections/${esc(e.id)}/forms/${esc(b.id)}" target="_blank" rel="noopener">Voir le PDF</a>` : '<span class="chip amber">En attente</span>'}</div></div>`).join('')
    : '<div class="empty">Les binômes élus remplissent leur acte de candidature sur le site. Il arrive ici automatiquement.</div>'}
      ${e.rounds.length ? `<div style="margin-top:14px"><button class="btn secondary" data-action="pv">Préparer le procès-verbal (PDF)</button></div>` : ''}</div>`;

    const binomes = `<div class="panel"><div class="panel-head"><h2>Binômes en lice</h2><span class="chip">${e.binomes.length}</span></div>
      ${e.binomes.length ? e.binomes.map((b) => `<div class="person"><div><div class="nm">${esc(b.titulaire)} + ${esc(b.suppleant)}</div>
        <div class="muted small">Inscrit par ${esc(b.registrant)}</div></div>
        <div class="meta">${b.elected ? '<span class="chip green">Élu</span>' : ''}
        ${e.status === 'lobby' ? `<button class="btn ghost small" data-action="remove-binome" data-id="${esc(b.id)}" aria-label="Retirer le binôme ${esc(b.titulaire)}">Retirer</button>` : ''}</div></div>`).join('')
    : '<div class="empty">Les binômes candidats apparaîtront ici.</div>'}</div>`;

    const order = { pending: 0, accepted: 1, refused: 2 };
    const people = `<div class="panel"><div class="panel-head"><h2>Élèves connectés</h2><span class="chip">${accepted.length} validé${accepted.length > 1 ? 's' : ''}</span></div>
      ${e.participants.length ? [...e.participants].sort((a, b) => order[a.status] - order[b.status] || a.pseudo.localeCompare(b.pseudo, 'fr')).map((p) => `
        <div class="person"><div class="nm">${esc(p.pseudo)}</div><div class="meta">
          ${p.status === 'pending' ? `<button class="btn danger small" data-action="refuse" data-pid="${esc(p.id)}">Refuser</button><button class="btn ok small" data-action="accept" data-pid="${esc(p.id)}">Accepter</button>` : ''}
          ${p.status === 'accepted' ? `${p.role ? `<span class="chip grey">${p.role === 'candidate' ? 'Candidat' : 'Électeur'}</span>` : ''}${e.status === 'voting' ? `<span class="chip ${p.voted ? 'green' : 'amber'}">${p.voted ? 'A voté' : 'N\'a pas voté'}</span>` : '<span class="chip green">Validé</span>'}
            <button class="btn ghost small" data-action="remove-person" data-pid="${esc(p.id)}" aria-label="Retirer ${esc(p.pseudo)}">Retirer</button>` : ''}
          ${p.status === 'refused' ? '<span class="chip red">Refusé</span>' : ''}</div></div>`).join('')
    : '<div class="empty">Personne n\'est encore connecté. Donner le code aux élèves.</div>'}</div>`;

    const danger = `<div style="text-align:right"><button class="btn ghost small" data-action="delete-election">Supprimer cette élection</button></div>`;

    mount('t-election', skeleton, { head, action, results, forms, binomes, people, danger });
    updateApprove();
  }

  /* ------------------------------------------------------------ */
  /* Élève                                                         */
  /* ------------------------------------------------------------ */
  function renderStudent() {
    const st = S.student;
    if (!st) return spinner();

    if (st.status === 'pending') {
      return mount('s-pending', '<div class="student center"><section data-region="c"></section></div>', {
        c: `<span class="chip amber"><span class="dot pulse"></span>En attente</span>
          <h1 style="font-size:56px;margin-top:14px">Le professeur va valider ton pseudo</h1>
          <p class="muted" style="margin-top:10px">Connecté en tant que <b>${esc(st.pseudo)}</b> dans la classe ${esc(st.className)}. Cette page se mettra à jour toute seule.</p>`,
      });
    }
    if (st.status === 'refused') {
      return mount('s-refused', '<div class="student center"><section data-region="c"></section></div>', {
        c: `<span class="chip red">Pseudo refusé</span>
          <h1 style="font-size:52px;margin-top:14px">Ce pseudo n'a pas été accepté</h1>
          <p class="muted" style="margin:10px 0 20px">Se reconnecter avec le code et un pseudo que le professeur reconnaîtra (prénom, par exemple).</p>
          <button class="btn big" data-action="logout">Choisir un autre pseudo</button>`,
      });
    }

    const hasR2 = st.rounds.some((r) => r.round === 2) || st.phase.round === 2;
    const headHtml = `<div class="class-line"><h1>${esc(st.className)}</h1><span class="chip">${esc(st.pseudo)}</span></div>
      <div style="margin-top:16px">${stepper(st.phase.status, st.phase.round, hasR2)}</div>`;

    /* Choix du rôle */
    if (!st.role) {
      const canCand = st.phase.status === 'lobby';
      const choice = `<h2 style="margin-bottom:6px">Bienvenue, ${esc(st.pseudo)}</h2>
        <p class="muted" style="margin-bottom:16px">Choisir comment participer à l'élection.</p>
        <div class="role-cards">
          <button class="role-card" data-action="role-candidate" ${canCand ? '' : 'disabled'}><h2>Candidat</h2><span class="muted">Se présenter avec un suppléant pour devenir délégué.${canCand ? '' : ' Les candidatures sont closes.'}</span></button>
          <button class="role-card" data-action="role-voter"><h2>Électeur</h2><span class="muted">Voter pour les binômes de la classe, à bulletin secret.</span></button>
        </div>`;
      const cform = S.roleForm && canCand ? `<div class="panel"><h2 style="margin-bottom:4px">Ton binôme</h2>
        <p class="muted" style="margin-bottom:16px">Indiquer le nom et le prénom du titulaire et du suppléant.</p>
        <form data-form="candidate" novalidate>
          <fieldset class="fieldset"><legend>Titulaire</legend><div class="two-cols">
            <div class="field"><label for="t-pre">Prénom</label><input id="t-pre" name="t_prenom" type="text" maxlength="40" autocomplete="off" required></div>
            <div class="field"><label for="t-nom">Nom</label><input id="t-nom" name="t_nom" type="text" maxlength="40" autocomplete="off" required></div></div></fieldset>
          <fieldset class="fieldset"><legend>Suppléant</legend><div class="two-cols">
            <div class="field"><label for="s-pre">Prénom</label><input id="s-pre" name="s_prenom" type="text" maxlength="40" autocomplete="off" required></div>
            <div class="field"><label for="s-nom">Nom</label><input id="s-nom" name="s_nom" type="text" maxlength="40" autocomplete="off" required></div></div></fieldset>
          <p class="err" role="alert" data-err></p>
          <div class="row"><button class="btn big" type="submit">Enregistrer le binôme</button><button class="btn ghost" type="button" data-action="cancel-role">Annuler</button></div>
        </form></div>` : '';
      return mount('s-role', `<div class="student"><section data-region="head"></section><section data-region="choice"></section><section data-region="cform"></section></div>`,
        { head: headHtml, choice, cform });
    }

    /* Écran principal */
    if (S.selRound !== `${st.phase.status}-${st.phase.round}`) { S.selection.clear(); S.selRound = `${st.phase.status}-${st.phase.round}`; }
    const skeleton = `<div class="student"><section data-region="head"></section><section data-region="body" class="stack"></section>
      <section data-region="results" class="stack"></section><section data-region="form"></section></div>`;
    let body = '';
    const p = st.phase;

    if (p.status === 'lobby') {
      body = `<div class="notice ${st.role === 'candidate' ? 'green' : ''}">${st.role === 'candidate'
        ? '<b>Candidature enregistrée.</b> Le professeur ouvrira le vote quand toutes les candidatures seront là.'
        : '<b>Le vote n\'a pas encore commencé.</b> Voici les binômes déjà candidats, la liste se met à jour en direct.'}</div>
        <div><div class="panel-head"><h2>Binômes en lice</h2><span class="chip">${st.binomes.length}</span></div>
        ${st.binomes.length ? `<div class="grid-ballots">${st.binomes.map((b) => ballot(b, { cls: b.mine ? 'mine' : '', tag: b.mine ? '<span class="chip">Ton binôme</span>' : '' })).join('')}</div>`
    : '<div class="empty">Aucun binôme pour le moment.</div>'}</div>
        ${st.role === 'candidate' ? '<div><button class="btn danger small" data-action="withdraw">Retirer ma candidature</button></div>' : ''}`;
    } else if (p.status === 'voting') {
      if (st.hasVoted) {
        body = `<div class="panel" style="text-align:center;padding:36px 20px"><span class="done-stamp">A voté</span>
          <p style="margin-top:22px;font-weight:600">Ton vote est enregistré.</p>
          <p class="muted" style="margin-top:6px;max-width:44ch;margin-inline:auto">Il est anonyme : le site ne garde aucun lien entre toi et ton choix. Les résultats s'afficheront quand le professeur clôturera le tour.</p></div>`;
      } else {
        const cands = st.binomes.filter((b) => st.ballotCandidates.includes(b.id));
        const max = st.maxChoices;
        body = `<div><h2>${p.round === 1 ? '1er' : '2nd'} tour</h2>
          <p style="margin-top:6px">Choisir jusqu'à <b>${max} binôme${max > 1 ? 's' : ''}</b>, ou voter blanc.
          ${p.round === 2 ? '<span class="muted">Majorité relative : les plus votés sont élus.</span>' : ''}</p></div>
          <div class="grid-ballots" role="group" aria-label="Binômes candidats">${cands.map((b) => ballot(b, { button: true, cls: b.mine ? 'mine' : '' })).join('')}</div>
          <div class="votebar"><span class="count" id="vote-count" aria-live="polite">0 choix sur ${max}</span>
            <div class="actions"><button class="btn secondary" data-action="vote-blank">Voter blanc</button>
            <button class="btn" id="vote-go" data-action="vote" disabled>Valider mon vote</button></div></div>`;
      }
    } else {
      const lastRound = st.rounds[st.rounds.length - 1];
      const electedB = st.binomes.filter((b) => st.elected.includes(b.id));
      body = `${p.tie ? '<div class="notice amber"><b>Égalité.</b> Le professeur va départager les binômes concernés.</div>' : ''}
        ${p.status === 'finished' ? `<div class="notice green"><b>Élection terminée.</b> ${electedB.length ? 'Voici les délégués de la classe.' : 'Aucun binôme élu.'}</div>`
    : (!p.tie && p.seatsLeft > 0 ? `<div class="notice"><b>${lastRound ? (lastRound.round === 1 ? '1er tour terminé.' : '') : ''}</b> ${plural(p.seatsLeft, 'siège reste', 'sièges restent')} à pourvoir : le professeur peut lancer un second tour.</div>` : '')}
        ${electedB.length ? `<div><div class="panel-head"><h2>Délégués élus</h2></div><div class="grid-ballots">${electedB.map((b) => ballot(b, { cls: 'elected' + (b.mine ? ' mine' : '') })).join('')}</div></div>` : ''}`;
    }

    const results = p.status === 'results' || p.status === 'finished' ? resultsPanels(st.rounds, st.binomes, st.elected) : '';

    let form = '';
    if (st.form) {
      const f = st.form;
      const ta = (name, label, hint, val) => `<div class="field"><label for="f-${name}">${label}</label><span class="hint">${hint}</span>
        <textarea id="f-${name}" name="${name}" maxlength="1200" required>${esc(val)}</textarea></div>`;
      form = `<div class="panel"><div class="panel-head"><h2>Acte de candidature</h2>
          ${f.submittedAt ? `<span class="chip green">Envoyé le ${fmtDate(f.submittedAt)}</span>` : '<span class="chip amber">À remplir</span>'}</div>
        <p class="muted" style="margin-bottom:16px">Ce binôme est élu. Remplir le formulaire : il est transmis directement au professeur.</p>
        <form data-form="acte" novalidate>
          <div class="field"><label for="f-cl">Classe</label><input id="f-cl" type="text" value="${esc(f.classe)}" readonly></div>
          <div class="two-cols"><div class="field"><label for="f-ti">Nom, prénom du titulaire</label><input id="f-ti" type="text" value="${esc(f.titulaire)}" readonly></div>
          <div class="field"><label for="f-su">Nom, prénom du suppléant</label><input id="f-su" type="text" value="${esc(f.suppleant)}" readonly></div></div>
          ${ta('presentation', 'Présentez-vous brièvement', 'Nom, âge, qualités', f.presentation)}
          ${ta('motivations', 'Vos motivations', 'Pourquoi vous avez choisi d\'être candidats, comment le titulaire a choisi son suppléant', f.motivations)}
          ${ta('programme', 'Votre programme', 'Votre rôle auprès de la classe, des professeurs, de l\'administration, vos projets', f.programme)}
          <div class="field"><label for="f-slogan">Votre slogan</label><input id="f-slogan" name="slogan" type="text" maxlength="140" value="${esc(f.slogan)}" required></div>
          <p class="err" role="alert" data-err></p>
          <div class="row"><button class="btn big" type="submit">${f.submittedAt ? 'Renvoyer une version corrigée' : 'Envoyer au professeur'}</button>
          ${f.submittedAt ? '<a class="btn secondary" href="/api/student/form.pdf" target="_blank" rel="noopener">Voir le PDF</a>' : ''}</div>
        </form></div>`;
    }
    mount('s-main', skeleton, { head: headHtml, body, results, form });
  }

  function syncSelection() {
    const st = S.student;
    if (!st || !$('#vote-count')) return;
    $$('.ballot[data-id]').forEach((b) => b.setAttribute('aria-pressed', String(S.selection.has(b.dataset.id))));
    const n = S.selection.size;
    $('#vote-count').textContent = `${n} choix sur ${st.maxChoices}`;
    $('#vote-go').disabled = n === 0;
  }

  /* ------------------------------------------------------------ */
  /* Rendu global                                                  */
  /* ------------------------------------------------------------ */
  function render() {
    renderTopbar();
    const m = S.me;
    if (!m) return spinner();
    if (!m.role) { updateApprove(); return renderAuth(); }
    if (m.role === 'teacher') return S.currentId ? renderTeacherElection() : renderTeacherList();
    return renderStudent();
  }

  async function refreshMe() {
    try { S.me = await api('/me'); } catch { S.me = { role: null }; }
  }

  async function sync() {
    if (!S.me || !S.me.role) return;
    try {
      if (S.me.role === 'teacher') {
        if (S.currentId) S.election = await api(`/teacher/elections/${encodeURIComponent(S.currentId)}`);
        else S.list = (await api('/teacher/elections')).elections;
      } else {
        S.student = await api('/student/state');
      }
    } catch (err) {
      if (err.status === 401) { S.me = { role: null }; connectStream(); }
      else if (err.status === 404 && S.currentId) { S.currentId = null; S.election = null; location.hash = '#/'; return; }
    }
    render();
  }

  /* ------------------------------------------------------------ */
  /* Temps réel                                                    */
  /* ------------------------------------------------------------ */
  let es = null;
  function connectStream() {
    if (es) { es.close(); es = null; }
    if (!S.me || !S.me.role) return;
    es = new EventSource('/api/stream');
    es.addEventListener('change', () => sync());
  }
  setInterval(() => { if (!document.hidden) sync(); }, 30000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) sync(); });

  function readHash() {
    const m = location.hash.match(/^#\/e\/([\w-]+)$/);
    S.currentId = m ? m[1] : null;
    S.election = null;
    S.dismissed.clear();
  }
  window.addEventListener('hashchange', () => {
    readHash();
    if (S.me && S.me.role === 'teacher') { render(); sync(); }
  });

  async function afterLogin() {
    await refreshMe();
    readHash();
    if (S.me.role === 'teacher' && !S.currentId) location.hash = '#/';
    connectStream();
    render();
    await sync();
  }

  /* ------------------------------------------------------------ */
  /* Événements                                                    */
  /* ------------------------------------------------------------ */
  document.addEventListener('input', (ev) => {
    if (ev.target.matches('.code-input')) ev.target.value = ev.target.value.replace(/\D/g, '').slice(0, 6);
  });

  async function run(btn, fn) {
    if (btn) btn.disabled = true;
    try { await fn(); } catch (err) { toast(err.message, true); } finally { if (btn && btn.isConnected) btn.disabled = false; }
  }
  const eid = () => encodeURIComponent(S.currentId);
  const teacherAction = async (type, extra = {}) => {
    S.election = await api(`/teacher/elections/${eid()}/action`, { method: 'POST', body: { type, ...extra } });
    render();
  };

  document.addEventListener('submit', async (ev) => {
    const form = ev.target.closest('form[data-form]');
    if (!form) return;
    ev.preventDefault();
    const kind = form.dataset.form;
    const f = Object.fromEntries(new FormData(form));
    const errEl = $('[data-err]', form);
    const setErr = (m) => { if (errEl) errEl.textContent = m; };
    const btn = $('button[type=submit]', form);
    setErr('');
    if (btn) btn.disabled = true;
    try {
      if (kind === 'join') { await api('/join', { method: 'POST', body: { code: f.code, pseudo: f.pseudo } }); S.roleForm = false; await afterLogin(); return; }
      if (kind === 'tlogin') { await api('/teacher/login', { method: 'POST', body: f }); await afterLogin(); return; }
      if (kind === 'tregister') { await api('/teacher/register', { method: 'POST', body: f }); await afterLogin(); return; }
      if (kind === 'newElection') {
        const r = await api('/teacher/elections', { method: 'POST', body: { className: f.className } });
        location.hash = `#/e/${r.id}`; return;
      }
      if (kind === 'candidate') {
        await api('/student/role', { method: 'POST', body: { role: 'candidate', titulaire: { prenom: f.t_prenom, nom: f.t_nom }, suppleant: { prenom: f.s_prenom, nom: f.s_nom } } });
        S.roleForm = false; await sync(); toast('Binôme enregistré'); return;
      }
      if (kind === 'acte') {
        await api('/student/form', { method: 'POST', body: { presentation: f.presentation, motivations: f.motivations, programme: f.programme, slogan: f.slogan } });
        await sync(); toast('Acte de candidature envoyé au professeur'); return;
      }
      if (kind === 'tie') {
        const choices = new FormData(form).getAll('tie');
        await teacherAction('resolveTie', { choices }); toast('Égalité départagée'); return;
      }
    } catch (err) {
      setErr(err.message);
    } finally {
      if (btn && btn.isConnected) btn.disabled = false;
    }
  });

  document.addEventListener('click', async (ev) => {
    const t = ev.target.closest('[data-action]');
    if (!t) return;
    const a = t.dataset.action;
    const d = t.dataset;

    switch (a) {
      case 'tab': S.tab = d.tab; render(); break;
      case 'tmode': S.tmode = d.mode; render(); break;
      case 'logout':
        await run(t, async () => {
          await api('/logout', { method: 'POST' });
          S.me = { role: null }; S.student = null; S.election = null; S.list = null; S.currentId = null; S.roleForm = false;
          if (es) { es.close(); es = null; }
          $('#approve').open && $('#approve').close();
          history.replaceState(null, '', location.pathname);
          render();
        });
        break;

      /* ----- professeur ----- */
      case 'copy-code':
        try { await navigator.clipboard.writeText(d.code); toast('Code copié'); } catch { toast('Copie impossible : sélectionner le code à la main', true); }
        break;
      case 'copy-link':
        try { await navigator.clipboard.writeText(`${location.origin}/?code=${d.code}`); toast('Lien copié'); } catch { toast('Copie impossible', true); }
        break;
      case 'accept': case 'refuse':
        await run(t, async () => {
          await api(`/teacher/elections/${eid()}/participants/${encodeURIComponent(d.pid)}`, { method: 'POST', body: { decision: a } });
          await sync();
        });
        break;
      case 'later': {
        const dlg = $('#approve'); dlg.close(); break;
      }
      case 'remove-person':
        if (await confirmBox('Retirer cet élève ?', '<p>Son binôme éventuel sera aussi retiré. Il pourra se reconnecter avec le code.</p>', 'Retirer', 'danger')) {
          await run(t, async () => { await api(`/teacher/elections/${eid()}/participants/${encodeURIComponent(d.pid)}`, { method: 'POST', body: { decision: 'remove' } }); await sync(); });
        }
        break;
      case 'remove-binome':
        await run(t, async () => { await api(`/teacher/elections/${eid()}/binomes/${encodeURIComponent(d.id)}`, { method: 'DELETE' }); await sync(); });
        break;
      case 'start-vote':
        if (await confirmBox('Ouvrir le vote ?', '<p>Les candidatures seront closes. Les élèves pourront voter immédiatement.</p>', 'Ouvrir le vote')) {
          await run(t, () => teacherAction('startVote'));
        }
        break;
      case 'close-round': {
        const e = S.election;
        const t2 = e.turnout || { voted: 0, total: 0 };
        const missing = t2.total - t2.voted;
        if (await confirmBox(`Clôturer le ${e.round === 1 ? '1er' : '2nd'} tour ?`,
          `<p>${missing > 0 ? `<b>${plural(missing, 'élève n\'a pas encore voté', 'élèves n\'ont pas encore voté')}.</b> ` : ''}Après la clôture, plus aucun vote n'est possible et les résultats s'affichent pour tout le monde.</p>`, 'Clôturer', 'danger')) {
          await run(t, () => teacherAction('closeRound'));
        }
        break;
      }
      case 'start-round2':
        await run(t, () => teacherAction('startRound2'));
        break;
      case 'finish':
        if (await confirmBox('Terminer sans second tour ?', '<p>Les sièges restants ne seront pas pourvus.</p>', 'Terminer')) {
          await run(t, () => teacherAction('finish'));
        }
        break;
      case 'delete-election':
        if (await confirmBox('Supprimer cette élection ?', '<p>Tous les élèves, votes et formulaires seront effacés définitivement.</p>', 'Supprimer', 'danger')) {
          await run(t, async () => { await api(`/teacher/elections/${eid()}`, { method: 'DELETE' }); location.hash = '#/'; });
        }
        break;
      case 'pv': {
        const e = S.election;
        const today = new Date().toISOString().slice(0, 10);
        const acc = e.participants.filter((p) => p.status === 'accepted').length;
        const r2 = e.rounds.some((r) => r.round === 2);
        const res = await modal('Procès-verbal', `<p class="muted" style="margin-bottom:14px">Ces informations complètent le PDF. Les résultats sont repris automatiquement.</p>
          <div class="field"><label for="pv-t">Nom du professeur (M. / Mme)</label><input id="pv-t" name="teacher" type="text" maxlength="60"></div>
          <div class="pv-grid"><div class="field"><label for="pv-d">Date de l'élection</label><input id="pv-d" name="date" type="date" value="${today}"></div>
          <div class="field"><label for="pv-e">Élèves dans la classe</label><input id="pv-e" name="effectif" type="number" min="0" max="200" value="${acc}"></div>
          <div class="field"><label for="pv-a1">Absents (1er tour)</label><input id="pv-a1" name="absents1" type="number" min="0" max="200" value="0"></div>
          ${r2 ? '<div class="field"><label for="pv-a2">Absents (2nd tour)</label><input id="pv-a2" name="absents2" type="number" min="0" max="200" value="0"></div>' : ''}
          <div class="field"><label for="pv-s1">Assesseur 1</label><input id="pv-s1" name="assessor1" type="text" maxlength="60"></div>
          <div class="field"><label for="pv-s2">Assesseur 2</label><input id="pv-s2" name="assessor2" type="text" maxlength="60"></div></div>`,
        [{ label: 'Annuler', value: 'cancel', cls: 'secondary' }, { label: 'Générer le PDF', value: 'ok' }]);
        if (res.value === 'ok') {
          const q = new URLSearchParams();
          for (const [k, v] of res.form.entries()) if (String(v).trim()) q.set(k, v);
          const link = document.createElement('a');
          link.href = `/api/teacher/elections/${eid()}/pv?${q}`; link.target = '_blank'; link.rel = 'noopener';
          document.body.appendChild(link); link.click(); link.remove();
        }
        break;
      }

      /* ----- élève ----- */
      case 'role-candidate': S.roleForm = true; render(); setTimeout(() => $('#t-pre') && $('#t-pre').focus(), 0); break;
      case 'cancel-role': S.roleForm = false; render(); break;
      case 'role-voter':
        await run(t, async () => { await api('/student/role', { method: 'POST', body: { role: 'voter' } }); await sync(); });
        break;
      case 'withdraw':
        if (await confirmBox('Retirer ta candidature ?', '<p>Tu pourras te réinscrire tant que le vote n\'a pas commencé.</p>', 'Retirer', 'danger')) {
          await run(t, async () => { await api('/student/withdraw', { method: 'POST' }); await sync(); });
        }
        break;
      case 'toggle': {
        const max = S.student.maxChoices;
        if (S.selection.has(d.id)) S.selection.delete(d.id);
        else if (max === 1) { S.selection.clear(); S.selection.add(d.id); }
        else if (S.selection.size >= max) { toast(`Maximum ${max} choix : décocher un binôme d'abord`, true); break; }
        else S.selection.add(d.id);
        syncSelection();
        break;
      }
      case 'vote': case 'vote-blank': {
        const blank = a === 'vote-blank';
        const chosen = S.student.binomes.filter((b) => S.selection.has(b.id));
        const body = blank
          ? '<p>Un bulletin blanc compte comme votant mais ne soutient aucun binôme.</p>'
          : `<p>Tu votes pour :</p><ul>${chosen.map((b) => `<li><b>${esc(b.titulaire)}</b> + ${esc(b.suppleant)}</li>`).join('')}</ul>`;
        if (await confirmBox(blank ? 'Voter blanc ?' : 'Confirmer ton vote ?', `${body}<p class="muted small" style="margin-top:12px">Un vote est définitif et anonyme.</p>`, blank ? 'Voter blanc' : 'Confirmer')) {
          await run(t, async () => {
            await api('/student/vote', { method: 'POST', body: blank ? { blank: true } : { choices: [...S.selection] } });
            S.selection.clear(); await sync();
          });
        }
        break;
      }
      default: break;
    }
  });

  /* ------------------------------------------------------------ */
  /* Démarrage                                                     */
  /* ------------------------------------------------------------ */
  (async () => {
    spinner();
    await refreshMe();
    readHash();
    connectStream();
    render();
    await sync();
  })();
})();
