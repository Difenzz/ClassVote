# Élection des délégués

Site d'élection des délégués de classe : connexion professeur / élève, code à 6 chiffres,
validation des pseudos en direct, candidats / électeurs, vote à bulletin secret,
second tour, acte de candidature rempli sur le site puis renvoyé au professeur (PDF),
procès-verbal en PDF.

## Lancer le site

Il faut Node.js 18 ou plus.

```bash
npm install
npm start
```

Le site est alors sur http://localhost:3000. Au démarrage, la console affiche le
**code d'invitation professeur** : il faut le saisir pour créer un compte professeur
(sinon un élève pourrait s'inscrire comme professeur). On peut le fixer soi-même avec
la variable `TEACHER_INVITE`.

Pour tester que tout fonctionne : `npm test`.

## Mettre en ligne

Le site a besoin d'un serveur (les élèves sont sur des appareils différents). Il tourne
tel quel sur Render, Railway, Fly.io, un VPS ou un serveur d'établissement.

| Variable | Rôle |
| --- | --- |
| `PORT` | Port d'écoute (3000 par défaut). |
| `APP_SECRET` | Secret principal, 32 caractères minimum. S'il est absent, il est généré dans `data/secret.key`. |
| `TEACHER_INVITE` | Code d'invitation pour créer un compte professeur. |
| `DATA_DIR` | Dossier des données (`./data` par défaut). Sur un hébergeur, le placer sur un disque persistant. |
| `TRUST_PROXY=1` | À activer derrière un proxy HTTPS (Render, Railway…) : cookies `Secure` et vraie IP pour la limitation de tentatives. |

Utiliser **HTTPS** en production. **Sauvegarder `APP_SECRET`** (ou `data/secret.key`) : sans lui,
les identifiants professeurs ne peuvent plus être déchiffrés ni retrouvés.

## Comment ça marche

1. Le professeur crée un compte, puis une élection (nom de la classe). Un code à 6 chiffres est généré.
2. Les élèves saisissent le code et un pseudo. Une fenêtre s'ouvre chez le professeur : **Accepter** ou **Refuser**.
3. Chaque élève validé choisit **Candidat** (nom et prénom du titulaire et du suppléant) ou **Électeur**.
   Les binômes s'affichent en direct chez tout le monde.
4. Le professeur ouvre le **1er tour**. Chaque élève choisit jusqu'à 2 binômes (ou vote blanc).
   Un binôme est élu s'il obtient la **majorité absolue** des suffrages exprimés (moitié + 1).
5. Si des sièges restent vides, le professeur lance le **2nd tour** (majorité relative) entre les binômes non élus.
6. En cas d'égalité, le site l'indique et le professeur départage (règle du dossier : le titulaire le plus jeune est élu).
7. Les binômes élus remplissent l'**acte de candidature** sur le site. Le professeur le reçoit en PDF.
8. Le professeur peut générer le **procès-verbal** en PDF (résultats repris automatiquement).

## Sécurité et secret du vote

- **Identifiants professeurs** : chiffrés en AES-256-GCM. La recherche se fait avec une empreinte HMAC, sans jamais stocker l'identifiant en clair.
- **Mots de passe** : hachés avec scrypt, sel unique par compte.
- **Bulletin secret** : le serveur stocke uniquement des compteurs par binôme et, pour chaque élève, un simple « a voté ». Aucun choix, aucune heure de vote, aucun journal ne relie un élève à un binôme. Les résultats restent cachés jusqu'à la clôture du tour.
- **Sessions** : cookie `HttpOnly` + `SameSite=Strict`, seule l'empreinte du jeton est stockée.
- **Autres protections** : limitation des tentatives (connexion, code de classe), protection CSRF, en-têtes de sécurité (CSP), échappement de toutes les données affichées.

## Limites connues

- Les données sont dans un fichier JSON : prévu pour un seul serveur, pas pour plusieurs instances en parallèle. C'est largement suffisant pour des classes.
- Le dossier mentionne qu'un élève non candidat peut être élu s'il accepte : cette règle n'est pas gérée, seuls les binômes inscrits peuvent être votés.
- Le formulaire du dossier (.docx) est reproduit en PDF par le site, avec la même trame (classe, titulaire, suppléant, présentation, motivations, programme, slogan).
- Les élections sont supprimées automatiquement après 30 jours.

## Polices

Big Shoulders Display et Public Sans (licence SIL OFL), hébergées dans `public/fonts`.
