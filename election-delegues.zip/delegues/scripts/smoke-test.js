'use strict';
/* Test de bout en bout : node scripts/smoke-test.js (aucune dépendance, Node 18+) */
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

const PORT = 3900 + Math.floor(Math.random() * 90);
const BASE = `http://127.0.0.1:${PORT}`;
const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'deleg-'));
const OUT = process.env.PDF_OUT || null;
let failures = 0;
const ok = (cond, label) => { if (cond) console.log('  ok  ', label); else { failures++; console.log('  FAIL', label); } };

function client() {
  let cookie = '';
  return async (method, url, body, raw = false) => {
    const r = await fetch(BASE + url, {
      method,
      headers: { 'Content-Type': 'application/json', ...(cookie ? { Cookie: cookie } : {}) },
      body: method === 'GET' ? undefined : JSON.stringify(body || {}),
    });
    const sc = r.headers.get('set-cookie');
    if (sc) cookie = sc.split(';')[0];
    if (raw) return { status: r.status, buf: Buffer.from(await r.arrayBuffer()), type: r.headers.get('content-type') };
    let data = null; try { data = await r.json(); } catch { /* */ }
    return { status: r.status, data };
  };
}

async function main() {
  const srv = spawn('node', [path.join(__dirname, '..', 'server.js')], {
    env: { ...process.env, PORT, DATA_DIR: DATA, TEACHER_INVITE: 'TESTINV' }, stdio: ['ignore', 'pipe', 'inherit'],
  });
  await new Promise((res) => srv.stdout.on('data', (d) => { if (String(d).includes('Code')) res(); }));

  try {
    console.log('Professeur');
    const T = client();
    ok((await T('POST', '/api/teacher/register', { identifiant: 'mme.dupont', password: 'motdepasse-solide', invite: 'nope' })).status === 403, 'mauvais code d\u2019invitation refusé');
    ok((await T('POST', '/api/teacher/register', { identifiant: 'mme.dupont', password: 'court', invite: 'TESTINV' })).status === 400, 'mot de passe trop court refusé');
    ok((await T('POST', '/api/teacher/register', { identifiant: 'mme.dupont', password: 'motdepasse-solide', invite: 'TESTINV' })).status === 200, 'inscription');
    const T2 = client();
    ok((await T2('POST', '/api/teacher/login', { identifiant: 'MME.DUPONT', password: 'mauvais-mot-de-passe' })).status === 401, 'mauvais mot de passe refusé');
    ok((await T2('POST', '/api/teacher/login', { identifiant: 'MME.DUPONT', password: 'motdepasse-solide' })).status === 200, 'connexion (identifiant insensible à la casse)');
    ok((await T2('GET', '/api/me')).data.identifiant === 'mme.dupont', 'identifiant déchiffré à la lecture');
    await new Promise((r) => setTimeout(r, 400));
    const raw = fs.readFileSync(path.join(DATA, 'db.json'), 'utf8');
    ok(!raw.includes('mme.dupont') && !raw.includes('motdepasse'), 'identifiant et mot de passe absents du fichier de données');
    ok(/"pw":"scrypt\$/.test(raw), 'mot de passe haché (scrypt)');
    ok((await client()('GET', '/api/teacher/elections')).status === 401, 'API professeur protégée');

    console.log('Élection 1 (second tour)');
    const { data: created } = await T('POST', '/api/teacher/elections', { className: '2nde 4' });
    const eid = created.id;
    let view = (await T('GET', `/api/teacher/elections/${eid}`)).data;
    ok(/^\d{6}$/.test(view.code), `code à 6 chiffres généré (${view.code})`);
    const code = view.code;

    ok((await client()('POST', '/api/join', { code: '000000', pseudo: 'Zoe' })).status === 404, 'code inconnu refusé');
    const names = ['s1', 's2', 's3', 's4', 's5', 's6'];
    const S = {};
    for (const n of names) {
      S[n] = client();
      ok((await S[n]('POST', '/api/join', { code, pseudo: n })).status === 200, `${n} rejoint`);
    }
    ok((await client()('POST', '/api/join', { code, pseudo: 's1' })).status === 409, 'pseudo en double refusé');
    ok((await S.s1('GET', '/api/student/state')).data.status === 'pending', 'élève en attente de validation');
    ok((await S.s1('POST', '/api/student/role', { role: 'voter' })).status === 403, 'rôle impossible avant validation');
    view = (await T('GET', `/api/teacher/elections/${eid}`)).data;
    for (const p of view.participants) await T('POST', `/api/teacher/elections/${eid}/participants/${p.id}`, { decision: 'accept' });
    ok((await S.s1('GET', '/api/student/state')).data.status === 'accepted', 'validation par le professeur');

    const cand = (n, t, s) => S[n]('POST', '/api/student/role', { role: 'candidate', titulaire: t, suppleant: s });
    ok((await cand('s1', { prenom: 'léa', nom: 'martin' }, { prenom: 'Hugo', nom: 'Bernard' })).status === 200, 'binôme A enregistré');
    ok((await cand('s2', { prenom: 'Léa', nom: 'Martin' }, { prenom: 'Zoé', nom: 'Roy' })).status === 400, 'élève déjà dans un binôme refusé');
    ok((await cand('s2', { prenom: 'Inès', nom: 'Petit' }, { prenom: 'Yanis', nom: 'Morel' })).status === 200, 'binôme B enregistré');
    ok((await cand('s3', { prenom: 'Sam', nom: 'Girard' }, { prenom: 'Nina', nom: 'Faure' })).status === 200, 'binôme C enregistré');
    for (const n of ['s4', 's5', 's6']) await S[n]('POST', '/api/student/role', { role: 'voter' });

    const st = (await S.s4('GET', '/api/student/state')).data;
    const id = Object.fromEntries(st.binomes.map((b) => [b.titulaire.split(' ')[0], b.id]));
    const [A, B, C] = [id['Léa'], id['Inès'], id['Sam']];
    ok(A && B && C, 'les 3 binômes sont visibles par les élèves');
    ok(st.binomes[0].titulaire === 'Sam GIRARD' || st.binomes.length === 3, 'noms normalisés');

    ok((await S.s4('POST', '/api/student/vote', { choices: [A] })).status === 400, 'vote refusé avant l\u2019ouverture');
    ok((await T('POST', `/api/teacher/elections/${eid}/action`, { type: 'startVote' })).status === 200, 'vote ouvert (1er tour)');
    ok((await cand('s6', { prenom: 'Tard', nom: 'Venu' }, { prenom: 'Aussi', nom: 'Tard' })).status === 400, 'candidature refusée après ouverture');

    const vote = (n, body) => S[n]('POST', '/api/student/vote', body);
    ok((await vote('s1', { choices: [A, B, C] })).status === 400, 'plus de 2 choix refusé');
    ok((await vote('s1', { choices: ['inconnu'] })).status === 400, 'binôme invalide refusé');
    ok((await vote('s1', { choices: [A, B] })).status === 200, 's1 vote A+B');
    ok((await vote('s1', { choices: [A] })).status === 409, 'double vote refusé');
    await vote('s2', { choices: [A] }); await vote('s3', { choices: [A, C] });
    await vote('s4', { choices: [A, B] }); await vote('s5', { choices: [C] }); await vote('s6', { blank: true });
    view = (await T('GET', `/api/teacher/elections/${eid}`)).data;
    ok(view.turnout.voted === 6 && view.rounds.length === 0, 'participation visible, résultats cachés pendant le vote');
    ok((await S.s1('GET', '/api/student/state')).data.rounds.length === 0, 'résultats cachés aux élèves pendant le vote');

    const dbDump = JSON.stringify(JSON.parse(fs.readFileSync(path.join(DATA, 'db.json'), 'utf8')));
    await new Promise((r) => setTimeout(r, 300));
    const dbNow = JSON.parse(fs.readFileSync(path.join(DATA, 'db.json'), 'utf8'));
    const parts = Object.values(dbNow.elections[eid].participants);
    ok(parts.every((p) => Object.values(p.voted).every((v) => v === true) && !('choices' in p) && !('vote' in p)), 'secret : aucun choix stocké par élève');
    ok(dbDump.length > 0, 'base lisible');

    await T('POST', `/api/teacher/elections/${eid}/action`, { type: 'closeRound' });
    view = (await T('GET', `/api/teacher/elections/${eid}`)).data;
    const r1 = view.rounds[0];
    const votes = Object.fromEntries(r1.tally.map((t) => [t.id, t.votes]));
    ok(votes[A] === 4 && votes[B] === 2 && votes[C] === 2, 'décompte 1er tour (A=4, B=2, C=2)');
    ok(r1.blanks === 1 && r1.exprimes === 5 && r1.threshold === 3, 'blancs, exprimés et majorité absolue');
    ok(view.elected.length === 1 && view.elected[0] === A && view.status === 'results', 'A élu à la majorité absolue, second tour possible');

    ok((await T('POST', `/api/teacher/elections/${eid}/action`, { type: 'startRound2' })).status === 200, 'second tour lancé');
    const st2 = (await S.s1('GET', '/api/student/state')).data;
    ok(st2.maxChoices === 1 && !st2.ballotCandidates.includes(A) && st2.ballotCandidates.length === 2, 'second tour : 1 siège, binôme élu exclu');
    ok((await vote('s1', { choices: [A] })).status === 400, 'vote pour un binôme déjà élu refusé');
    ok((await vote('s1', { choices: [B, C] })).status === 400, 'un seul choix au second tour');
    await vote('s1', { choices: [B] }); await vote('s2', { choices: [B] }); await vote('s3', { choices: [B] });
    await vote('s4', { choices: [C] }); await vote('s5', { choices: [C] }); await vote('s6', { blank: true });
    await T('POST', `/api/teacher/elections/${eid}/action`, { type: 'closeRound' });
    view = (await T('GET', `/api/teacher/elections/${eid}`)).data;
    ok(view.status === 'finished' && view.elected.includes(A) && view.elected.includes(B), 'élection terminée : A et B élus');

    console.log('Formulaire et PDF');
    ok((await S.s3('POST', '/api/student/form', { presentation: 'x', motivations: 'x', programme: 'x', slogan: 'x' })).status === 403, 'binôme non élu ne peut pas remplir l\u2019acte');
    const stA = (await S.s1('GET', '/api/student/state')).data;
    ok(stA.form && stA.form.titulaire === 'Léa MARTIN' && stA.form.classe === '2nde 4', 'formulaire prérempli pour le binôme élu');
    ok((await S.s1('POST', '/api/student/form', { presentation: '', motivations: 'm', programme: 'p', slogan: 's' })).status === 400, 'champ vide refusé');
    ok((await S.s1('POST', '/api/student/form', {
      presentation: 'Léa, 15 ans, curieuse et à l\u2019écoute.\nHugo, 15 ans, organisé.',
      motivations: 'Représenter la classe et défendre nos idées – œuvre commune.',
      programme: 'Relais auprès des professeurs, boîte à idées, sortie de fin d\u2019année.',
      slogan: 'Ensemble, on avance !',
    })).status === 200, 'acte envoyé par A');
    await S.s2('POST', '/api/student/form', { presentation: 'Inès et Yanis', motivations: 'Motivés', programme: 'Écoute', slogan: 'Deux voix, un cap' });
    view = (await T('GET', `/api/teacher/elections/${eid}`)).data;
    ok(view.binomes.filter((b) => b.formAt).length === 2, 'le professeur voit les 2 actes reçus');
    const pdf = await T('GET', `/api/teacher/elections/${eid}/forms/${A}`, null, true);
    ok(pdf.status === 200 && pdf.type === 'application/pdf' && pdf.buf.subarray(0, 4).toString() === '%PDF', 'PDF de l\u2019acte de candidature');
    const pv = await T('GET', `/api/teacher/elections/${eid}/pv?teacher=Mme%20Dupont&assessor1=Ana&assessor2=Tom&effectif=28&absents1=2&absents2=3&date=2026-10-02`, null, true);
    ok(pv.status === 200 && pv.buf.subarray(0, 4).toString() === '%PDF', 'PDF du procès-verbal');
    ok((await S.s1('GET', '/api/student/form.pdf', null, true)).status === 200, 'l\u2019élève peut relire son PDF');
    if (OUT) { fs.mkdirSync(OUT, { recursive: true }); fs.writeFileSync(path.join(OUT, 'acte.pdf'), pdf.buf); fs.writeFileSync(path.join(OUT, 'pv.pdf'), pv.buf); }

    console.log('Élection 2 (égalité)');
    const e2 = (await T('POST', '/api/teacher/elections', { className: '3e B' })).data.id;
    const code2 = (await T('GET', `/api/teacher/elections/${e2}`)).data.code;
    const V = {};
    for (const n of ['a', 'b', 'c', 'd']) { V[n] = client(); await V[n]('POST', '/api/join', { code: code2, pseudo: 'e2-' + n }); }
    for (const p of (await T('GET', `/api/teacher/elections/${e2}`)).data.participants) await T('POST', `/api/teacher/elections/${e2}/participants/${p.id}`, { decision: 'accept' });
    await V.a('POST', '/api/student/role', { role: 'candidate', titulaire: { prenom: 'Xavier', nom: 'Xu' }, suppleant: { prenom: 'Xenia', nom: 'Xu' } });
    await V.b('POST', '/api/student/role', { role: 'candidate', titulaire: { prenom: 'Yann', nom: 'Yu' }, suppleant: { prenom: 'Yara', nom: 'Yu' } });
    await V.c('POST', '/api/student/role', { role: 'candidate', titulaire: { prenom: 'Zoe', nom: 'Zu' }, suppleant: { prenom: 'Zara', nom: 'Zu' } });
    await V.d('POST', '/api/student/role', { role: 'voter' });
    const ids = Object.fromEntries((await V.d('GET', '/api/student/state')).data.binomes.map((b) => [b.titulaire[0], b.id]));
    await T('POST', `/api/teacher/elections/${e2}/action`, { type: 'startVote' });
    await V.a('POST', '/api/student/vote', { choices: [ids.X] }); await V.b('POST', '/api/student/vote', { choices: [ids.Y] });
    await V.c('POST', '/api/student/vote', { choices: [ids.Z] }); await V.d('POST', '/api/student/vote', { choices: [ids.X] });
    await T('POST', `/api/teacher/elections/${e2}/action`, { type: 'closeRound' });
    let v2 = (await T('GET', `/api/teacher/elections/${e2}`)).data;
    ok(v2.elected.length === 0 && v2.status === 'results', 'aucune majorité absolue au 1er tour');
    await T('POST', `/api/teacher/elections/${e2}/action`, { type: 'startRound2' });
    await V.a('POST', '/api/student/vote', { choices: [ids.X] }); await V.b('POST', '/api/student/vote', { choices: [ids.Y] });
    await V.c('POST', '/api/student/vote', { choices: [ids.Z] }); await V.d('POST', '/api/student/vote', { choices: [ids.X] });
    await T('POST', `/api/teacher/elections/${e2}/action`, { type: 'closeRound' });
    v2 = (await T('GET', `/api/teacher/elections/${e2}`)).data;
    ok(v2.elected.length === 1 && v2.tie && v2.tie.slots === 1 && v2.tie.candidates.length === 2, 'X élu, égalité Y/Z détectée');
    ok((await T('POST', `/api/teacher/elections/${e2}/action`, { type: 'resolveTie', choices: [ids.Y, ids.Z] })).status === 400, 'départage : nombre de choix contrôlé');
    ok((await T('POST', `/api/teacher/elections/${e2}/action`, { type: 'resolveTie', choices: [ids.Y] })).status === 200, 'départage validé');
    v2 = (await T('GET', `/api/teacher/elections/${e2}`)).data;
    ok(v2.status === 'finished' && v2.elected.length === 2, 'élection 2 terminée');

    console.log('Isolation');
    const T3 = client();
    await T3('POST', '/api/teacher/register', { identifiant: 'autre.prof', password: 'un-autre-mot-de-passe', invite: 'TESTINV' });
    ok((await T3('GET', `/api/teacher/elections/${eid}`)).status === 404, 'un professeur ne voit pas les élections d\u2019un autre');
    ok((await S.s1('GET', '/api/teacher/elections')).status === 401, 'un élève n\u2019accède pas à l\u2019API professeur');
    const bad = await fetch(`${BASE}/api/join`, { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: '{}' });
    ok(bad.status === 415, 'requête non JSON refusée (CSRF)');
    const trav = await fetch(`${BASE}/..%2f..%2fserver.js`);
    ok(trav.status !== 200 || !(await trav.text()).includes('createServer'), 'pas de traversée de dossier');
  } finally {
    srv.kill('SIGTERM');
    fs.rmSync(DATA, { recursive: true, force: true });
  }
  console.log(failures ? `\n${failures} test(s) en échec` : '\nTous les tests passent');
  process.exit(failures ? 1 : 0);
}
main().catch((e) => { console.error(e); process.exit(1); });
